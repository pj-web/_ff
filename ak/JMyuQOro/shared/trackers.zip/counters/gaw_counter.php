<!-- Global site tag (gtag.js) - AdWords: 861860520 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=<?= $counterId ?>"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', '<?= $counterId ?>');
</script>

<?php if ($lead && $convId) : ?>
<!-- Event snippet for Example conversion page -->
<script>
  gtag('event', 'conversion', {'send_to': '<?= $counterId ?>/<?= $convId ?>'});
</script>
<?php endif ?>