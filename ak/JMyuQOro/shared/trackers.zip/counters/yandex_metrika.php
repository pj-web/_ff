
<!-- Yandex.Metrika counter -->
<script type="text/javascript">

if (window.orderValidator) {
    $(document).on('validate.success', 'form', function(e) {
        if (window['yaCounter<?= $counterId ?>'] && e.validator === window.orderValidator) {
            window['yaCounter<?= $counterId ?>'].reachGoal('ORDER');
        }
    });
}

$(document).on('click', 'form', function(e) {
    if ( ! $(this).find('input[name=phone]').length) {
        return;
    }
    
    if (window['yaCounter<?= $counterId ?>'] && e.validator === window.orderValidator) {
        window['yaCounter<?= $counterId ?>'].reachGoal('FORMCLICK');
    }
});

(function (d, w, c) {
    (w[c] = w[c] || []).push(function() {
        try {
            var y = new Ya.Metrika({
                id: <?= $counterId ?>,
                webvisor: <?= $webvisor ? 'true' : 'false' ?>,
                clickmap: true,
                trackLinks: true,
                accurateTrackBounce: true
            });
            if (w.yandex_metrika_inject) {
                w.yandex_metrika_inject(y);
            }
            w['yaCounter<?= $counterId ?>'] = y;
        } catch(e) { }
    });

    var n = d.getElementsByTagName("script")[0],
        s = d.createElement("script"),
        f = function () { n.parentNode.insertBefore(s, n); };
    s.type = "text/javascript";
    s.async = true;
    s.src = (d.location.protocol == "https:" ? "https:" : "http:") + "//mc.yandex.ru/metrika/watch.js";

    if (w.opera == "[object Opera]") {
        d.addEventListener("DOMContentLoaded", f, false);
    } else { f(); }
})(document, window, "yandex_metrika_callbacks");

</script>

<noscript><div><img src="//mc.yandex.ru/watch/<?= $counterId ?>" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter --> 
