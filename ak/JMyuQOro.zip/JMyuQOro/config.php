<?php

$default_main_site = 'http://api.cpa.tl';
//$default_main_site = 'http://api.tradeblg.ru';
$landings_default_domain = 'antking-official.ru/black';
$shared_path = '/black';

$dispathchUrl = $default_main_site . '/api/tds/r/JMyuQOro/s';
$apiUrl = $default_main_site . '/api/lead/send_archive';

$apiKey = 'oaj38NPGzSy2VgGN7csFnbgLENhaZtddbkhSaWs1O';
$offer_id = 13445;
$stream_hid = 'JMyuQOro';
$landKey = '{land_key}';

$_debug = False; // установите True для вывода дополнительной информации для отладки и поиска ошибок