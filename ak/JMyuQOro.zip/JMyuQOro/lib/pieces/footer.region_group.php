<?php
global $landings_default_domain;
?>

<p>ООО «РЕГИОН ГРУПП»</p>
<p>119034, г. Москва, проезд Соймоновский, д. 7, стр. 1, пом. П, ком. 20</p>
<p>ОГРН: 1197746188474 ИНН: 7704482681</p>
<a href="#politika" onclick="window.open('http://<?= $landings_default_domain ?>/policy2.php'); return false;" class="politika popup-with-move-anim">Политика конфинденциальности</a>
