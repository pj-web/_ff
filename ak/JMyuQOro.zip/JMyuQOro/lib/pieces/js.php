<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<?php incl('pieces/js.app.php');
global $shared_path;
?>
<script src="<?php echo $shared_path ?>/shared/form.validate.js?11"></script>
<script src="<?php echo $shared_path ?>/shared/interPhoneCodes.js"></script>
<script src="<?php echo $shared_path ?>/shared/showcase.js"></script>
<!--<script src="--><?php //echo $shared_path ?><!--/shared/form.incomplete.js?10"></script>-->
<script src="<?php echo $shared_path ?>/shared/main.js?11"></script>
