<?php
global $shared_path;
?>
<link rel="stylesheet" href="<?php echo $shared_path ?>/shared/plugins/corona_delivery_top/style.css">
<?php global $language, $lang; ?>
<div id="corona_banner">
    <div class="corona-wrapper">
        <span class="corona-wrapper-close">x</span>
        <div style="background-position: left 0px center; padding-left: 60px;">
            <p><?php echo $lang['plugin_corona_1'] ?></p>
            <p><?php echo $lang['plugin_corona_2'] ?></p>
        </div>
    </div>
</div>
<script src="<?php echo $shared_path ?>/shared/plugins/corona_delivery_top/script.js"></script>