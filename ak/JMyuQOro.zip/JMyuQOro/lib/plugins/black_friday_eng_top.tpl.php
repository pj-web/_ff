<?php 
global $shared_path; 
?>

<link rel="stylesheet" href="<?= $shared_path ?>/shared/plugins/black_friday/style.css">
<link rel="stylesheet" href="<?= $shared_path ?>/shared/plugins/black_friday/eng/style.css">

<div class="black_friday__container">
    <span class="black_friday__close">x</span>

    <div class="black_friday__content">
        <div class="black_friday__startdate">Big sale!</div>
    </div>
</div>

<script src="<?= $shared_path ?>/shared/plugins/black_friday/script.js"></script>
