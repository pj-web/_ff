<?php

$default_main_site = 'http://api.cpa.tl';
//$default_main_site = 'http://api.tradeblg.ru';
$landings_default_domain = 'antking-official.ru';
$shared_path = '';

$dispathchUrl = $default_main_site . '/api/tds/r/VrxFlK92/s';
$apiUrl = $default_main_site . '/api/lead/send_archive';

$apiKey = 'oaj38NPGzSy2VgGN7csFnbgLENhaZtddbkhSaWs1O';
$offer_id = 6981;
$stream_hid = 'VrxFlK92';
$landKey = '{land_key}';

$_debug = False; // установите True для вывода дополнительной информации для отладки и поиска ошибок