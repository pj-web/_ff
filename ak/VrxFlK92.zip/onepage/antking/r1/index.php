<?php require('onepage.php') ?>  
<!DOCTYPE html>
<html lang="en">
<head>
    <script src=" https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <meta charset="UTF-8">
    <base >
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <title>ANT KING комплекс для потенции и увеличения члена</title>
    <link rel="stylesheet" href="dis/css/style.bundle.css">
    <link href="dis/favicon/favicon.ico" rel="icon" type="image/x-icon"/>   
<script type="text/javascript" src="dis/js/main.js"></script>
<!--
<script type="text/javascript" src="js/order.js"></script>
<script type="text/javascript" src="js/scripts_in_langings.js"></script>
-->
</head>
<body>
<div class="container-fluid  bcg1 ">
    <div class="row head3 hidden-md hidden-lg">

        <div class="col-lg-100 col-md-100 col-xs-100 col-sm-100  col-lg-offset-30 col-md-offset-28 " style="padding: 0">
            <div class="col-lg-15 col-md-15 col-xs-38 col-sm-42" style="padding:0;margin-top: 20px">
                <div class="media">
                    <div class="media-left media-top" style="padding-right: 3px">
                        <img src="dis/img/icon1_m.png" class="media-object">
                    </div>
                    <div class="media-body">
                        <p>Нам доверяют Более 1 МЛН. человек</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-13 col-md-13 col-xs-30 col-sm-28" style="padding: 0;margin-top: 20px">
                <div class="media">
                    <div class="media-left media-middle">
                        <img src="dis/img/icon1_1_m.png" class="media-object">
                    </div>
                    <div class="media-body">
                        <p>Мы есть в аптеках</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-14 col-md-14 col-xs-30 col-sm-28" style="padding: 0;margin-top: 20px">
                <div class="media">
                    <div class="media-left media-middle" style="padding-right: 0">
                        <img src="dis/img/icon1_2_m.png" class="media-object">
                    </div>
                    <div class="media-body">
                        <p>Результаты доказаны!</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-14 col-md-15 hidden-xs hidden-sm" style="padding: 0;margin-top: 20px">
                <div class="media">
                    <div class="media-left media-top">
                        <img src="dis/img/icon1_3_m.png" class="media-object">
                    </div>
                    <div class="media-body">
                        <span>Помогает всем и в любому возрасте</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container " style="padding: 2px;">
        <div class="row head hidden-xs hidden-sm">

            <div class="col-lg-100 col-md-100 col-xs-100 col-sm-100  col-lg-offset-30 col-md-offset-28 " style="padding: 0">
                <div class="col-lg-15 col-md-15 col-xs-36 col-sm-33" style="padding:0;margin-top: 20px">
                    <div class="media">
                        <div class="media-left media-top">
                            <img src="dis/img/icon1_m.png" class="media-object">
                        </div>
                        <div class="media-body">
                            <span>Нам доверяют Более 1 МЛН. человек</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-13 col-md-13 col-xs-30 col-sm-33" style="padding: 0;margin-top: 20px">
                    <div class="media">
                        <div class="media-left media-middle">
                            <img src="dis/img/icon1_1_m.png" class="media-object">
                        </div>
                        <div class="media-body">
                            <span>Мы есть</span><br><span>в аптеках</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-14 col-md-14 col-xs-30 col-sm-33" style="padding: 0;margin-top: 20px">
                    <div class="media">
                        <div class="media-left media-middle">
                            <img src="dis/img/icon1_2_m.png" class="media-object">
                        </div>
                        <div class="media-body">
                            <span>Результаты</span><br><span>доказаны!</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-14 col-md-15 hidden-xs hidden-sm" style="padding: 0;margin-top: 20px">
                    <div class="media">
                        <div class="media-left media-top">
                            <img src="dis/img/icon1_3_m.png" class="media-object">
                        </div>
                        <div class="media-body">
                            <span>Помогает всем и в любому возрасте</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row row2_bcg1">
            <div class="col-lg-100 col-md-100 col-xs-100 col-sm-100  col-lg-offset-27 col-md-offset-25" style="padding: 2px;">
                <div class="col-lg-43 col-md-45 col-xs-100 col-sm-100 " style="padding: 0;">
                    <div class="col-lg-100 col-md-100 col-xs-100 col-sm-100  text-center" style="padding: 0;">
                        <span class="title1_bcg1">ANT KING</span>
                        <p class="title2_bcg1">комплекс для потенции и увеличения члена</p>
                        <img class="img_bcg1" src="dis/img/img_bcg1.png" alt="">
                    </div>
                    <div class="col-lg-100 col-md-100 col-xs-100 col-sm-100  row3_bcg1" style="padding: 0;">
                        <div class="col-lg-30 col-md-30 col-xs-40 col-sm-50 " style="padding: 0;">
                            <img class="img2_bcg1" src="dis/img/pack.png" alt="">
                        </div>
                        <div class="col-lg-65 col-md-70 col-xs-60 col-sm-50 list_bcg1" style="padding: 0;">
                            <div class="media list1_bcg1">
                                <div class="media-left media-top">
                                    <img src="dis/img/ok.png"
                                         class="media-object" style="">
                                </div>
                                <div class="media-body">
                                    УВЕЛИЧИВАЕТ НЕ ТОЛЬКО
                                    В ДЛИНУ, НО И В ШИРИНУ
                                </div>
                            </div>
                            <div class="media list1_bcg1">
                                <div class="media-left media-top">
                                    <img src="dis/img/ok.png"
                                         class="media-object" style="">
                                </div>
                                <div class="media-body">
                                    БОЛЕЕ 1 000 000 ДОВОЛЬНЫХ МУЖЧИН
                                </div>
                            </div>
                            <div class="media list1_bcg1">
                                <div class="media-left media-top">
                                    <img src="dis/img/ok.png"
                                         class="media-object" style="">
                                </div>
                                <div class="media-body">
                                    НАТУРАЛЬНЫЙ <br> СОСТАВ
                                </div>
                            </div>

                            <div class="media list1_bcg1 hidden-xs hidden-sm">
                                <div class="media-left media-top">
                                    <img src="dis/img/ok.png"
                                         class="media-object" style="">
                                </div>
                                <div class="media-body">
                                    БЕЗ ПОБОЧных <br>
                                    эффектов
                                </div>
                            </div>
                            
                        </div>

                    </div>
                </div>
                <div class="col-lg-30 col-md-36 hidden-sm hidden-xs text-center" style="padding: 0;">
                    <div class="form-login magrin-top10">


                        <div class="row form_top2">

                            <div class="col-lg-100 col-md-100 " style="">
                                <div class="col-lg-50 col-md-50" style="padding: 0  ">
                                    <span class="form_text3">АКЦИЯ! ТОЛЬКО</span>
                                    <span class="form_text4">СЕГОДНЯ!</span>
                                </div>
                                <div class="col-lg-50 col-md-50" style="padding: 0;">
                                    <div class="col-lg-100 col-md-100 form_text1" style="padding: 0">цена: <?= $newPriceHtml ?> <?= $currencyDisplayHtml ?>
                                    </div>
                                  <!--  <div class="col-lg-100 col-md-100 form_text2" style="padding: 0">
                                        <span>ВМЕСТО </span><span
                                            class="custom_old"></span>
                                    </div>-->
                                </div>
                            </div>

                        </div>
                        <div class="row form_top" style="display:none">


                            <div class="col-lg-100 col-md-100 text-center">
                            <span class="text_form">
                                До конца акции осталось всего:
                            </span>
                            </div>
                            <div class="col-lg-100 col-md-100">
                                <div class="timer clearfix" style="display:none">
                        <span>
                            <b> {h10}{h1} </b>
                            часов
                        </span>
                                    <i> : </i>
                                    <span>
                            <b> {m10}{m1} </b>
                            минут
                        </span>
                                    <i> : </i>
                                    <span>
                            <b> {s10}{s1} </b>
                            секунд
                        </span>
                                </div>

                            </div>

                        </div>
                        <div class="row">
                            <form style="height: auto" method="post" action=""  >
                                <div class=""> <?= countrySelect() ?>   </div>
                                <div class="form_input">
                                    <input style="" type="text"
                                                               class=" form-control  " name="name"
                                                               placeholder="ВАШЕ ИМЯ" required="" >
                                </div>
                                <div class="form_input">
                                    <input style="" type="tel"
                                                               class=" form-control" name="phone"
                                                               placeholder="НОМЕР ТЕЛЕФОНА" required=""
                                                               >
                                </div>

                                <center>
                                    <input type="submit" name="button" class="btn1  magrin-top20"
                                               value="ЗАКАЗАТЬ СЕЙЧАС">
                                </center>
                            </form>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<div class="container-fluid  bcg2 ">
    <div class="container ">
        <div class="row ">
            <div class="col-lg-100 col-md-100 col-xs-100 col-sm-100  text-center_mb col-md-offset-9" style="padding: 0">
                <div class="col-lg-50 col-md-50  col-xs-100 col-sm-100 " style="padding: 0;"><span class="title1_bcg2">
    БОЛЬШЕ,</span><br class="hidden-lg hidden-md"><span class="title2_bcg2"> ДЛИННЕЕ, ШИРЕ</span>
                    <div class="col-xs-100 col-sm-100 hidden-md hidden-lg row_bcg2">
                        <div class="col-xs-50 col-sm-50 text-left " style="padding: 0">
                            <img class="img_bcg2" src="dis/img/penis1.png" alt="">
                            <p class="text_bcg2">до ANT KING</p>
                        </div>
                        <div class="col-xs-50 col-sm-50 text-left" style="padding: 0">
                            <img class="img2_bcg2" src="dis/img/penis2.png" alt="">
                            <p class="text_bcg2">после <br>
                                ANT KING</p>
                        </div>
                        <div class="col-sm-100 col-xs-100" style="padding: 0;">
                            <p class="title3_bcg2 ">ANT KING - единственное работающее средство
                                на рынке для увеличения члена. Этот комплекс, который
                                <span class="bold"> не вызывает никаких побочных эффектов</span>,
                                не вызывает аллергических реакций. Специальные ферменты, входящие в состав, <span class="bold">благотворно влияют на ткани пениса</span>,
                                которые безвредно растягиваются,
                                а с ними и камеры кавернозного тела полового члена, что и способствует реальному увеличению
                                как и в длине так и в обхвате. </p>
                        </div>
                    </div>
                    <p class="title3_bcg2 hidden-xs hidden-sm">ANT KING - единственное работающее средство
                        на рынке для увеличения члена. Этот комплекс, который
                        <span class="bold"> не вызывает никаких побочных эффектов</span>,
                        не вызывает аллергических реакций. Специальные ферменты, входящие в состав, <span class="bold">благотворно влияют на ткани пениса</span>,
                        которые безвредно растягиваются,
                        а с ними и камеры кавернозного тела полового члена, что и способствует реальному увеличению
                        как и в длине так и в обхвате. </p></div>
                <div class="col-lg-50 col-md-50 col-xs-100 col-sm-100 hidden-sm hidden-xs">
                    <div class="col-lg-40 col-md-40 text-left" style="padding: 0">
                        <img class="img_bcg2" src="dis/img/penis1.png" alt="">
                        <p class="text_bcg2">до ANT KING</p>
                    </div>
                    <div class="col-lg-50 col-md-50 text-left" style="padding: 0">
                        <img class="img2_bcg2" src="dis/img/penis2.png" alt="">
                        <p class="text_bcg2">после <br>
                            ANT KING</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid  bcg3 ">

    <div class="container " style="padding: 0">
        <div class="row ">

            <div class="col-lg-100 col-md-100 col-xs-100 col-sm-100" style="padding: 0">
                <div class="col-lg-50 col-md-55 col-xs-100 col-sm-100 col-lg-offset-25 col-md-offset-15  magrin-top30" style="padding: 0">
                    <div class="text-center_mb"><span class="title1_bcg3">
                    ВСЕГО
                </span><span class="title2_bcg3">
                   3 ЭТАПА
                </span></div>
                    <div class="media list_bcg3">
                        <div class="media-left media-middle">
                            <img src="dis/img/list1_bcg3.png" class="media-object">
                        </div>
                        <div class="media-body">
                            <span class="media-heading txt_bcg3">1 этап</span>
                            <p class="txt2_bcg3">5 эфирных масел готовят кожу к растяжению</p>
                        </div>
                    </div>
                    <div class="media list2_bcg3">
                        <div class="media-left media-middle">
                            <img src="dis/img/list2_bcg3.png" class="media-object">
                        </div>
                        <div class="media-body">
                            <span class="media-heading txt_bcg3">2 этап</span>
                            <p class="txt2_bcg3">Активные пектины наращивают ткани органа и в длину, и в диаметре </p>
                        </div>
                    </div>
                    <div class="media list_bcg3">
                        <div class="media-left media-middle">
                            <img src="dis/img/list3_bcg3.png" class="media-object">
                        </div>
                        <div class="media-body">
                            <span class="media-heading txt_bcg3">3 этап</span>
                            <p class="txt2_bcg3">Железо, натрий, цинк, кальций, обеспечивают продолжительный эффект</p>
                        </div>
                    </div>
                </div>

            </div>
            <img class="img_bcg3 hidden-sm hidden-xs" src="dis/img/bcg3_chel.png" alt="">
        </div>
    </div>
</div>

<div class="container-fluid  bcg4 ">
    <div class="container ">
        <div class="row ">
            <div class="col-lg-100 col-md-100 col-xs-100 col-sm-100 text-center">
                <span class="title1_bcg2">ПОЧЕМУ ИМЕННО</span>
                <span class="title2_bcg2">ANT KING</span>

            </div>
            <div class="col-lg-100 col-md-100 col-xs-100 col-sm-100 row_bcg4">
                <div class="col-lg-33 col-md-33 col-xs-100 col-sm-100 magrin-top30_bcg4 text-center">
                    <img class="center-block img_bcg4" src="dis/img/list1_bcg4.png" alt="">
                    <span class="list_bcg4">Увеличение члена до +7 см </span><br>
                    <span class="list_bcg4">Увеличение диаметра до +5 см</span>
                </div>
                <div class="col-lg-33 col-md-33 col-xs-100 col-sm-100 magrin-top30_bcg4 text-center">
                    <img class="center-block img_bcg4" src="dis/img/list2_bcg4.png" alt="">
                    <span class="list_bcg4">Без побочных</span><br>
                    <span class="list_bcg4">эффектов и аллергии</span>
                </div>
                <div class="col-lg-33 col-md-33 col-xs-100 col-sm-100 magrin-top30_bcg4 text-center">
                    <img class="center-block img_bcg4" src="dis/img/list3_bcg4.png" alt="">
                    <span class="list_bcg4" style="text-transform: uppercase">УСИЛЕНИЕ ЭРЕКЦИИ!</span><br>
                    <span class="list_bcg4">+ 200% к чувствительности оргазма </span>
                </div>

            </div>
        </div>
    </div>
</div>


<div class="container-fluid  bcg5 ">
    <div class="container ">
        <div class="row ">
            <div class="col-lg-100 col-md-100 col-xs-100 col-sm-100" style="padding: 0;">
                <div class="col-lg-50 col-md-50 col-xs-100 col-sm-100" style="padding: 0;">
                    <div class="col-lg-100 col-md-100 col-sm-100 col-xs-100" style="padding: 0;">
                        <span class="title1_bcg5">ЗАКАЖИТЕ <span class="hidden-xs hidden-sm">СЕГОДНЯ</span> <br>
                        <span class="hidden-xs hidden-sm">И</span> </span><span class="title2_bcg5"><span class="hidden-lg hidden-md">И</span> ПОЛУЧИТЕ ПОДАРОК!</span>
                    </div>
                    <div class="col-lg-40 col-md-40 col-xs-50 col-sm-25 text-center row2_bcg5" style="padding: 0;">
                        <span class="bonus_text">Получено подарков</span>
                        <div class="bonus bonus_plus">34870</div>
                    </div>
                    <div class="col-lg-25 col-md-25 col-xs-40 col-sm-20 text-center row2_bcg5" style="padding: ">
                        <span class="bonus_text">осталось</span>
                        <div class="bonus2 bonus_minus">130</div>
                    </div>
                    <img class="img_bcg5 hidden-xs hidden-sm" src="dis/img/podarok.png" alt="">
                </div>
                <div class="col-sm-100 col-xs-100 hidden-lg hidden-md" style="padding: 0;">
                    <div class="col-sm-50 col-xs-50" style="padding: 0;">
                        <img class="img2_bcg5" src="dis/img/pack3.png" alt="">
                    </div>
                    <div class="col-sm-50 col-xs-50" style="padding: 0;">
                        <img class="img_bcg5" src="dis/img/podarok.png" alt="">
                    </div>


                </div>
                <div class="col-lg-33 col-md-40 col-lg-offset-15 col-md-offset-10 hidden-sm hidden-xs text-center">
                    

                    <div class="form-login">


                        <div class="row form_top2">

                            <div class="col-lg-100 col-md-100 " style="">
                                <div class="col-lg-50 col-md-50" style="padding: 0  ">
                                    <span class="form_text3">АКЦИЯ! ТОЛЬКО</span>
                                    <span class="form_text4">СЕГОДНЯ!</span>
                                </div>
                                <div class="col-lg-50 col-md-50" style="padding: 0;">
                                    <div class="col-lg-100 col-md-100 form_text1" style="padding: 0">цена: <?= $newPriceHtml ?> <?= $currencyDisplayHtml ?>
                                    </div>
                                    <!--<div class="col-lg-100 col-md-100 form_text2" style="padding: 0">
                                        <span>ВМЕСТО </span><span
                                            class="custom_old"></span>
                                    </div>-->
                                </div>
                            </div>

                        </div>
                        <div class="row form_top" style="display:none">


                            <div class="col-lg-100 col-md-100 text-center">
                            <span class="text_form">
                                До конца акции осталось всего:
                            </span>
                            </div>
                            <div class="col-lg-100 col-md-100">
                                <div class="timer clearfix" style="display:none">
                        <span>
                            <b> {h10}{h1} </b>
                            часов
                        </span>
                                    <i> : </i>
                                    <span>
                            <b> {m10}{m1} </b>
                            минут
                        </span>
                                    <i> : </i>
                                    <span>
                            <b> {s10}{s1} </b>
                            секунд
                        </span>
                                </div>

                            </div>

                        </div>
                        <div class="row">
                            <form style="height: auto" method="post" action="">
                                <div class=""> <?= countrySelect() ?>   </div>

                                <div class="form_input"><input style="" type="text"
                                                               class=" form-control  " name="name"
                                                               placeholder="ВАШЕ ИМЯ" required="" >
                                </div>
                                <div class="form_input"><input style="" type="tel"
                                                               class=" form-control" name="phone"
                                                               placeholder="НОМЕР ТЕЛЕФОНА" required=""
                                                               >
                                </div>

                                <center><input type="submit" name="button" class="btn1  magrin-top20"
                                               value="ЗАКАЗАТЬ СЕЙЧАС">
                                </center>

                            
 </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid bcg5_mb hidden-lg hidden-md text-center">
    <div class="row">
        <div class="col-xs-100 col-sm-100" style="padding: 0;">
            <div class="form-login">


                <div class="row form_top2">

                    <div class="col-xs-100 col-sm-100 text-center" style="">
                        <div class="col-sm-50 col-xs-50" style="padding: 0  ">
                            <span class="form_text3">АКЦИЯ! ТОЛЬКО</span>
                            <span class="form_text4">СЕГОДНЯ!</span>
                        </div>
                        <div class="col-sm-50 col-xs-50" style="padding: 0;">
                            <div class="col-lg-100 col-md-100 form_text1" style="padding: 0">цена: <?= $newPriceHtml ?> <?= $currencyDisplayHtml ?>
                            </div>
                           <!-- <div class="col-xs-100 col-sm-100 form_text2" style="padding: 0">
                                <span>ВМЕСТО </span><span
                                    class="custom_old"></span>
                            </div>-->
                        </div>
                    </div>

                </div>
                <div class="row form_top" style="display:none">


                    <div class="col-xs-100 col-sm-100 text-center" style="padding: 0;">
                            <span class="text_form">
                                До конца акции осталось всего:
                            </span>
                    </div>
                    <div class="col-xs-100 col-sm-100" style="padding: 0;">
                        <div class="timer clearfix" style="display:none">
                        <span>
                            <b> {h10}{h1} </b>
                            часов
                        </span>
                            <i> : </i>
                            <span>
                            <b> {m10}{m1} </b>
                            минут
                        </span>
                            <i> : </i>
                            <span>
                            <b> {s10}{s1} </b>
                            секунд
                        </span>
                        </div>

                    </div>

                </div>
                <div class="row">
                    <form style="height: auto" method="post" action=""   >
<div class=""> <?= countrySelect() ?>   </div>

                        <div class="form_input"><input style="" type="text"
                                                       class=" form-control  " name="name"
                                                       placeholder="ВАШЕ ИМЯ" required="" >
                        </div>
                        <div class="form_input"><input style="" type="tel"
                                                       class=" form-control " name="phone"
                                                       placeholder="НОМЕР ТЕЛЕФОНА" required=""
                                                       >
                        </div>

                        <center><input type="submit" name="button" class="btn1  magrin-top20"
                                       value="ЗАКАЗАТЬ СЕЙЧАС">
                        </center>

                    
 </form>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid  bcg6 ">
    <div class="container ">
        <div class="row ">
            <div class="col-lg-100 col-md-100 text-center">
                <span class="title1_bcg6">ОТЗЫВЫ МУЖЧИН</span>
            </div>
            <div class="col-lg-100 col-md-100" style="padding: 0;">
                <div class="media center-block">
                    <div class="media-left media-top">
                        <img src="dis/img/list1_bcg6.png" class="media-object">
                    </div>
                    <div class="media-body">
                        <span class="media-heading txt_bcg6">Linovski4</span>
                        <p class="txt2_bcg6">Член растет на глазах! Использовать ANT KING очень просто и абсолютно безопасно. Я многое перепробовал, помпы, крема, таблетки. Эффекта не было вообще. Продолжаю использовать капсулы. Устраивает на 100%!  </p>
                    </div>
                </div>
                <div class="media center-block">
                    <div class="media-left media-top">
                        <img src="dis/img/list2_bcg6.png" class="media-object">
                    </div>
                    <div class="media-body">
                        <span class="media-heading txt_bcg6">AleksandВуlenres5688</span>
                        <p class="txt2_bcg6">С юности комплексовал по поводу маленького члена. Девственности лишился только в 18, и то, пришлось вынести унизительный взгляд. Сейчас прохожу курс терапии. Всего за 2 недели он увеличился на несколько см! Для меня это шок и радость.</p>
                    </div>
                </div>
                <div class="media center-block">
                    <div class="media-left media-top">
                        <img src="dis/img/list3_bcg6.png" class="media-object">
                    </div>
                    <div class="media-body">
                        <span class="media-heading txt_bcg6">Lebar117</span>
                        <p class="txt2_bcg6">Перед сексом помазал, член как-будто разбух и выпил пару капсул. Стал длиннее и толще.
                            Буду пользоваться дальше. Благо, цена нормальная.  </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="container-fluid bcg5_mb hidden-lg hidden-md" style="padding-top: 0px;height: 589px">
    <div class="row head2">

        <div class="col-lg-100 col-md-100 col-xs-100 col-sm-100  col-lg-offset-30 col-md-offset-28 " style="padding: 0;">
            <div class="col-lg-15 col-md-15 col-xs-37 col-sm-33" style="padding:0;margin-top: 20px">
                <div class="media">
                    <div class="media-left media-top">
                        <img src="dis/img/icon1_m.png" class="media-object">
                    </div>
                    <div class="media-body">
                        <p>Нам доверяют Более 1 МЛН. человек</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-13 col-md-13 col-xs-28 col-sm-33" style="padding: 0;margin-top: 20px">
                <div class="media">
                    <div class="media-left media-middle">
                        <img src="dis/img/icon1_1_m.png" class="media-object">
                    </div>
                    <div class="media-body">
                        <p>Мы есть в аптеках</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-14 col-md-14 col-xs-31 col-sm-33" style="padding: 0;margin-top: 20px">
                <div class="media">
                    <div class="media-left media-middle">
                        <img src="dis/img/icon1_2_m.png" class="media-object">
                    </div>
                    <div class="media-body">
                        <p>Результаты доказаны!</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-14 col-md-15 hidden-xs hidden-sm" style="padding: 0;margin-top: 20px">
                <div class="media">
                    <div class="media-left media-top">
                        <img src="dis/img/icon1_3_m.png" class="media-object">
                    </div>
                    <div class="media-body">
                        <span>Помогает всем и в любому возрасте</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row magrin-top20">
        <div class="col-lg-100 col-md-100 col-xs-100 col-sm-100  text-center" style="padding: 0;">
            <span class="title1_bcg1">ANT KING</span>
            <p class="title2_bcg1">комплекс для потенции и увеличения члена</p>
        </div>
    </div>
    <div class="row magrin-top20">
        <div class="col-xs-100 col-sm-100 text-center">
            <div class="form-login" id="scroll-target">


                <div class="row form_top2">

                    <div class="col-xs-100 col-sm-100 text-center" style="padding: 0;">
                        <div class="col-sm-50 col-xs-50" style="padding: 0  ">
                            <span class="form_text3">АКЦИЯ! ТОЛЬКО</span>
                            <span class="form_text4">СЕГОДНЯ!</span>
                        </div>
                        <div class="col-sm-50 col-xs-50" style="padding: 0;">
                            <div class="col-lg-100 col-md-100 form_text1" style="padding: 0">цена: <?= $newPriceHtml ?> <?= $currencyDisplayHtml ?>
                            </div>
                            <!--<div class="col-xs-100 col-sm-100 form_text2" style="padding: 0">
                                <span>ВМЕСТО </span><span
                                    class="custom_old"></span>
                            </div>-->
                        </div>
                    </div>

                </div>
                <div class="row form_top" style="display:none">


                    <div class="col-xs-100 col-sm-100 text-center">
                            <span class="text_form">
                                До конца акции осталось всего:
                            </span>
                    </div>
                    <div class="col-xs-100 col-sm-100">
                        <div class="timer clearfix" style="display:none">
                        <span>
                            <b> {h10}{h1} </b>
                            часов
                        </span>
                            <i> : </i>
                            <span>
                            <b> {m10}{m1} </b>
                            минут
                        </span>
                            <i> : </i>
                            <span>
                            <b> {s10}{s1} </b>
                            секунд
                        </span>
                        </div>

                    </div>

                </div>
                <div class="row">
                    <form style="height: auto" method="post" action=""   >
<div class=""> <?= countrySelect() ?>   </div>
                        <div class="form_input"><input style="" type="text"
                                                       class=" form-control  " name="name"
                                                       placeholder="ВАШЕ ИМЯ" required="" >
                        </div>
                        <div class="form_input"><input style="" type="tel"
                                                       class=" form-control" name="phone"
                                                       placeholder="НОМЕР ТЕЛЕФОНА" required=""
                                                       >
                        </div>

                        <center><input type="submit" name="button" class="btn1  magrin-top20"
                                       value="ЗАКАЗАТЬ СЕЙЧАС">
                        </center>

                    
 </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid  bcg7 hidden-sm hidden-xs">

    <div class="row ">
        <div class="container " style="padding: 0">
            <div class="col-lg-100 col-md-100">
                <div class="col-lg-67 col-md-60">
                    <div class="col-lg-100 col-md-100">
                        <span class="title1_bcg7">ANT KING</span><br>
                        <span class="title2_bcg7">секрет большого размера!</span>
                    </div>
                    <div class="col-lg-100 col-md-100">
                        <div class="col-lg-45 col-md-60 list_bcg7">
                            <div class="media list1_bcg1">
                                <div class="media-left media-top">
                                    <img src="dis/img/ok2.png"
                                         class="media-object" style="">
                                </div>
                                <div class="media-body">
                                    УВЕЛИЧИВАЕТ НЕ ТОЛЬКО
                                    В ДЛИНУ, НО И В ШИРИНУ
                                </div>
                            </div>
                            <div class="media list1_bcg1">
                                <div class="media-left media-top">
                                    <img src="dis/img/ok2.png"
                                         class="media-object" style="">
                                </div>
                                <div class="media-body">
                                    БОЛЕЕ 1 000 000 ДОВОЛЬНЫХ МУЖЧИН
                                </div>
                            </div>
                            <div class="media list1_bcg1">
                                <div class="media-left media-top">
                                    <img src="dis/img/ok2.png"
                                         class="media-object" style="">
                                </div>
                                <div class="media-body">
                                    НАТУРАЛЬНЫЙ <br> СОСТАВ
                                </div>
                            </div>
                            <div class="media list1_bcg1">
                                <div class="media-left media-top">
                                    <img src="dis/img/ok2.png"
                                         class="media-object" style="">
                                </div>
                                <div class="media-body">
                                    БЕЗ ПОБОЧных <br>
                                    эффектов
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-50 col-md-40">
                            <img class="img_bcg7" src="dis/img/pack2.png" alt="">

                        </div>
                    </div>
                </div>
                <div class="col-lg-33 col-md-40 text-center">
                    <div class="form-login">


                        <div class="row form_top2">

                            <div class="col-lg-100 col-md-100 " style="">
                                <div class="col-lg-50 col-md-50" style="padding: 0  ">
                                    <span class="form_text3">АКЦИЯ! ТОЛЬКО</span>
                                    <span class="form_text4">СЕГОДНЯ!</span>
                                </div>
                                <div class="col-lg-50 col-md-50" style="padding: 0;">
                                    <div class="col-lg-100 col-md-100 form_text1" style="padding: 0">цена: <?= $newPriceHtml ?> <?= $currencyDisplayHtml ?>
                                    </div>
                                   <!-- <div class="col-lg-100 col-md-100 form_text2" style="padding: 0">
                                        <span>ВМЕСТО </span><span
                                            class="custom_old"></span>
                                    </div>-->
                                </div>
                            </div>

                        </div>
                        <div class="row form_top" style="display:none">


                            <div class="col-lg-100 col-md-100 text-center">
                            <span class="text_form">
                                До конца акции осталось всего:
                            </span>
                            </div>
                            <div class="col-lg-100 col-md-100">
                                <div class="timer clearfix" style="display:none">
                        <span>
                            <b> {h10}{h1} </b>
                            часов
                        </span>
                                    <i> : </i>
                                    <span>
                            <b> {m10}{m1} </b>
                            минут
                        </span>
                                    <i> : </i>
                                    <span>
                            <b> {s10}{s1} </b>
                            секунд
                        </span>
                                </div>

                            </div>

                        </div>
                        <div class="row">
                            <form style="height: auto" action=""  method="post"  >
                                <div class=""> <?= countrySelect() ?>   </div>

                                <div class="form_input"><input style="" type="text"
                                                               class=" form-control  " name="name"
                                                               placeholder="ВАШЕ ИМЯ" required="" >
                                </div>
                                <div class="form_input"><input style="" type="tel"
                                                               class=" form-control" name="phone"
                                                               placeholder="НОМЕР ТЕЛЕФОНА" required=""
                                                               >
                                </div>

                                <center><input type="submit" name="button" class="btn1  magrin-top20"
                                               value="ЗАКАЗАТЬ СЕЙЧАС">
                                </center>

                            
 </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid info">
    <div class="container">
        <center>
            <div class="">
               <center>
                   <?= footer() ?>
               </center>
            </div>
        </center>
    </div>
</div>
<style>
.js_errorMessage{
   z-index: 11
}
.form-control{
    width: 100%;
}
</style>
</body>
</html>
