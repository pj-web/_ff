<?php global $shared_path; ?>


<link rel="stylesheet" href="<?= $shared_path ?>/shared/plugins/valentines_day/style.css">

<div class="valentines_day__container">
    <span class="valentines_day__close">x</span>

    <div class="valentines_day__content">
            <div>St. Valentine's Day Sale</div>
    </div>
</div>
<script src="<?= $shared_path ?>/shared/plugins/valentines_day/script.js"></script>