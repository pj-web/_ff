<?php
global $shared_path;
?>

<link rel="stylesheet" href="<?= $shared_path ?>/shared/plugins/february_23/style.css">
<link rel="stylesheet" href="<?= $shared_path ?>/shared/plugins/february_23/ru/style.css">

<div class="february_23_container">
    <span class="february_23_close">x</span>

    <div class="february_23_content">
        <div class="february_23_startdate">Большая распродажа!</div>
    </div>
</div>

<script src="<?= $shared_path ?>/shared/plugins/february_23/script.js"></script>
