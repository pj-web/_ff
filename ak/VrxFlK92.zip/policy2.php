<!DOCTYPE html>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  
  <title>Политика конфиденциальности</title>
  <meta name="viewport" content="width=device-width">
  <script type="text/javascript">
  function closePolitika() {
   window.close();
  }
  </script>
  <style>
    a.closelink { 
      display: block; 
      background: white; 
      padding: 10px; 
      border-bottom: 1px dashed gray;
      border-top: 1px dashed gray; 
      text-align: center; 
      color: black;
      text-decoration: none;
    }
  </style>
</head>
<body>

<a href="#" class="closelink" onclick="closePolitika(); return false;"> [ ЗАКРЫТЬ ]</a>

<p>
  Наш интернет-магазин уважительно относится к правам клиента. Соблюдается строгая конфиденциальность
  при оформлении заказа. Сведения надёжно сохраняются и защищены от передачи. 
</p>
<p>
  Согласием на обработку данных клиента исключительно с целью оказания услуг является размещение заказа
  на сайте.     
</p>
<p>
  К персональным данным относится личная информация о клиенте: домашний адрес; имя, фамилия, отчество;
  сведения о рождении; имущественное, семейное положение; личные контакты (телефон, электронная почта)
  и прочие сведения, которые перечислены в Законе РФ № 152-ФЗ «О персональных данных» от 27 июля 2006 г. 
</p>
<p>
  Клиент вправе отказаться от обработки персональных данных. Нами в данном случае гарантируется
  удаление с сайта всех персональных данных в трёхдневный срок в рабочее время. Подобный отказ клиент
  может оформить простым электронным письмом на адрес, указанный на странице нашего сайта. 
</p>
<a href="policy2.php" class="closelink" onclick="closePolitika(); return false;"> [ ЗАКРЫТЬ ]</a>



 
</body></html>