<?php require('preland.php'); ?>
<!DOCTYPE html>
<html>

<head>
<script src=" https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
  <meta content="text/html; charset=UTF-8" http-equiv="Content-Type">
  <meta charset="utf-8">
  <title>Как я увеличил член на 5.5 см за 14 дней?! / Maxim Онлайн</title>
  <meta content="width=device-width" name="viewport">
  <script src="js/bundle.js"></script>
  <link rel="stylesheet" href="css/style.bundle.css">

  <link rel="shortcut icon" href="favicon/favicon.ico" type="image/x-icon">
</head>

<body>

  <div class="wrap">
    <div class="content">
      <div class="post">
        <div class="info">
          Сергей Кораблев,
          <script type="text/javascript">
            d = new Date();
            p = new Date(d.getTime() - 0 * 86400000);
            monthA = '01,02,03,04,05,06,07,08,09,10,11,12'.split(',');
            var w = p.getDate();
            document.write(p.getDate() + '.' + monthA[p.getMonth()] + '.' + p.getFullYear());
          </script>
        </div>
        <h1>Как я увеличил член на 5.5 см за 14 дней?!</h1>
        <img src="img/rot.jpg" style="width: 50%; float: left;">
        <p>Всем привет, я Серега из города <span class="city"></span>. Мужики! Реальную тему открыл!<img src="img/do9w0pldwne.jpg" width="20px"> Короче, жил как все, обычной жизнью. Но казалось мне, что член у меня мелковат, как-то не уверенно себя чувствовал.
          <img
            src="img/vcqc1-ngsyk.jpg" width="20px"></p>
        <p>Да и бабы когда видели мой агрегат, что-то не особо впечатлялись. Хоть в открытую не говорили, но я понимал, что им тоже не нравится мой член.<img src="img/obhjuv51oac.jpg" width="20px"></p>
        <p>Но тут наткнулся в интернете на блог американского порноактера. Он, короче, раскрыл секрет огромного члена всех порноактеров - они мажут его специальным <a href="">кремом</a>. </p>
        <p>Ну ладно, думаю, попробую. Заказал, начал использовать. И через неделю измерил и ОХУЕЛ!<img src="img/maw6wnwxlhq.jpg" width="20px"></p>
        <center> <img src="img/photo-orig.jpg"> <br><small>Глядите, по размеру как бутылка!</small> </center>
        <p>Раньше член был 15 см, а теперь 20,5. И это всего лишь за одну неделю!!!</p>
        <p>Бабы теперь просто без ума от моего члена.<img src="img/y-om-9rccw0.jpg" width="20px"> Даже когда я в штанах, они видят, что там у меня есть чем их удивить. И дико хотят секса со мной. Да и я сам я себя куда уверенней чувствую.<img src="img/gphi1iooeey.jpg"
            width="20px"></p>
        <p>Думаю, сами понимаете, что это стоит попробовать, если хотите большой член, благодаря которому все телки захотят секса с вами. Так что дерзайте, мужики!</p>
        <p> <a href="" style="font-size: 35px;"><b>Вот ссылка где я сам заказывал.</b></a></p>
        <!-- <center><img src="//static54.trans-cdn.com/stu/members/files/img/social-c.png"></center> -->
      </div>
      <div class="vk-comment-load comment-id-1">
        <div class="vk-avatar"><img src="img/comm1.jpg"></div>
        <div class="vk-comment-name"><a href="">Дина Ростовская</a></div>
        <div class="vk-comment-text">ммммм... это очень хорошо, когда у мужчины большой мощный член)))</div>
        <div class="vk-comment-date">4 минуты назад | <a href=""><span class="vk-comment-answer">Комментировать</span></a></div>
        <div class="vk-comment-like"> </div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/comm2.jpg"></div>
        <div class="vk-comment-name"><a href="">Макс Братишкин</a></div>
        <div class="vk-comment-text">вчера забрал посылку с почты, всё хорошо. Уже начинаю использовать. Кстати по бабкам вообще нормально... еще и скидку 50% дали... акция там какая-то</div>
        <div class="vk-comment-date">6 минуты назад | <a href=""><span class="vk-comment-answer">Комментировать</span></a></div>
        <div class="vk-comment-like"> </div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/comm3.jpg"></div>
        <div class="vk-comment-name"><a href="">Роман Нагорный</a></div>
        <div class="vk-comment-text">Пользуюсь уже вторую неделю. Член УВЕЛИЧИЛСЯ на 2.5 см!!! Потенция такая, что моя думает что я на таблетках! :) Спасибо! <br><img src="img/comm01.jpg" style="width: 100%;"></div>
        <div class="vk-comment-date">7 минуты назад | <a href=""><span class="vk-comment-answer">Комментировать</span></a></div>
        <div class="vk-comment-like"> </div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/comm4.jpg"></div>
        <div class="vk-comment-name"><a href="">Алексей Коровичев</a></div>
        <div class="vk-comment-text">Хех. Прикольно. Завидую... Сейчас тоже закажу пожалуй =))</div>
        <div class="vk-comment-date">9 минуты назад | <a href=""><span class="vk-comment-answer">Комментировать</span></a></div>
        <div class="vk-comment-like"> </div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/comm5.jpg"></div>
        <div class="vk-comment-name"><a href="">Серега Василенко</a></div>
        <div class="vk-comment-text">Купил тоже со скидкой, понравилось! Спасибо</div>
        <div class="vk-comment-date">11 минуты назад | <a href=""><span class="vk-comment-answer">Комментировать</span></a></div>
        <div class="vk-comment-like"> </div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/comm6.jpg"></div>
        <div class="vk-comment-name"><a href="">Дмитрий Околов</a></div>
        <div class="vk-comment-text">Я применял этот майтитул. +4 см. Потом закинул... и так хватает)))<br><img src="img/comm02.jpg" style="width: 100%;"></div>
        <div class="vk-comment-date">12 минуты назад | <a href=""><span class="vk-comment-answer">Комментировать</span></a></div>
        <div class="vk-comment-like"> </div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/comm7.jpg"></div>
        <div class="vk-comment-name"><a href="">Александра Тихонова</a></div>
        <div class="vk-comment-text">Ух ты, срочно иду заказывать своему мужу!!!</div>
        <div class="vk-comment-date">15 минуты назад | <a href=""><span class="vk-comment-answer">Комментировать</span></a></div>
        <div class="vk-comment-like"> </div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/comm8.jpg"></div>
        <div class="vk-comment-name"><a href="">Саня Μолчанов</a></div>
        <div class="vk-comment-text">Это далеко не новость. Об этом креме уже все знают. А кто не знает, те, видимо, и не стремятся увеличить член. У меня результат +6СМ!!! <br><img src="img/comm03.jpg" style="width: 100%;"></div>
        <div class="vk-comment-date">19 минуты назад | <a href=""><span class="vk-comment-answer">Комментировать</span></a></div>
        <div class="vk-comment-like"> </div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/comm9.jpg"></div>
        <div class="vk-comment-name"><a href="">Adidad Proxorov</a></div>
        <div class="vk-comment-text">Ради интереса заказал, посмотрим что получиться. Вроде все показано доходчиво.</div>
        <div class="vk-comment-date">21 минуты назад | <a href=""><span class="vk-comment-answer">Комментировать</span></a></div>
        <div class="vk-comment-like"> </div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/comm10.jpg"></div>
        <div class="vk-comment-name"><a href="">Лина Павлова</a></div>
        <div class="vk-comment-text">Я тоже знаю про этот крем Майти-тул. У меня муж всё сидит тренеруется и изучает. +2см точно есть :D</div>
        <div class="vk-comment-date">25 минуты назад | <a href=""><span class="vk-comment-answer">Комментировать</span></a></div>
        <div class="vk-comment-like"> </div>
      </div>
    </div>
    <div class="photo">
      <div class="breadcrumbs"> <span>Фото дня с Miss Maxim</span> </div>
      <center><img src="img/4.jpg"></center>
    </div>
    <center><a href="" style="font-size: 32px;">ЗАКАЗАТЬ ANT KING</a></center>
    <br>
  </div>
  <script id="scripts"></script>

</body>

</html>