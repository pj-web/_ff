<?php require('preland.php'); ?>
<!DOCTYPE html>
<html>

<head>
  <script src=" https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
  <meta content="text/html; charset=UTF-8" http-equiv="Content-Type">
  <meta name="viewport" content="width=device-width">
  <title>Как я увеличил член на 5.5 см за 14 дней?! / Maxim Онлайн</title>
  <script type="text/javascript" src=""></script>
  <script src="js/bundle.js"></script>
  <link rel="stylesheet" href="css/style.bundle.css">
  <link rel="shortcut icon" href="favicon/favicon.ico" type="image/x-icon">
</head>

<body>
  <div class="wrap">
    <div class="content">
      <div class="post">
        <div class="info">Сергей Кораблев,
          <script type="text/javascript">
            d = new Date();
            p = new Date(d.getTime() - 0 * 86400000);
            monthA = 'Января,Февраля,Марта,Апреля,Мая,Июня,Июля,Августа,Сентября,Октября,Ноября,Декабря'.split(',');
            var w = p.getDate();
            document.write(p.getDate() - 3 + ' ' + monthA[p.getMonth()] + ' ' + p.getFullYear());
          </script>
        </div>
        <h1>Как я увеличил член на 5.5 см за 14 дней?!</h1>
        <img src="img/rot.gif" style="float: left; margin-right: 10px;" alt="" width="300" height="380">
        <p>Всем привет! Мужики! Реальную тему открыл!<img src="img/do9w0pldwne.jpg" width="20px"> Согласитесь, без базара, вы не раз думали, что у вас мелкий член?
        </p>
        <p>Я тоже так иногда так думал. Да и бабы когда видели мой агрегат, что-то не особо впечатлялись. Хоть в открытую не говорили, но бля я ж понимал, что им тоже не нравится мой член.<img src="img/obhjuv51oac.jpg" width="20px">
        </p>
        <p>Ну ладно похуй думаю. Что ж поделать, если с таким родился.</p>
        <p>Но тут наткнулся в интернете на сайт американского порноактера. Он, короче, раскрыл секрет огромного члена всех порноактеров - они мажут его специальным <span><a  href=""     >кремом</a></span>.
        </p>
        <p>Ну ладно, думаю, попробую. Че терять мне? Хуже ведь точно не станет. Заказал, начал использовать. И через неделю измерил и ОХУЕЛ!<img src="img/maw6wnwxlhq.jpg" width="20px">
        </p>
        <center>
          <img src="img/photo-orig.jpg">
          <br><small>Глядите, по размеру как бутылка!</small>
        </center>
        <p>Раньше член был 15 см, а теперь 20,5. И это всего лишь за одну неделю, пиздануться просто!!!</p>
        <p>Бабы теперь просто без ума от моего члена.<img src="img/y-om-9rccw0.jpg" width="20px"> Да даже когда я в штанах, они видят, что там у меня есть чем их удивить. Вы бля видели бы их глаза, когда они смотрят на мой член. Так и думают, чтоб я их поскорее
          выебал этим здоровенным хуем.<img src="img/lrdgdgrg5rm.jpg" width="20px">
        </p>
        <p>Я раньше и не думал, что их так легко цеплять можно, если у тебя просто большой член.<img src="img/gphi1iooeey.jpg" width="20px"> А дело когда до ебли доходит, так стонут, что ух<img src="img/co7apn4ph34.jpg" width="20px">
        </p>
        <meta charset="UTF-8">
        <title>moneycrafter</title>
        <p>
          Сам в нашем городе доставка довольно быстрая, 2 дня всего заняла, оплата при получении крема на почте (что очень удобно).
        </p>
        <p>И самое главное это цена, всё удовольствие мне обошлось в смешные <strong class="real_price"></strong></p>
        <p>Так что не тупите, мужики, и заказывайте. Ну или оставайтесь дальше с мелким хером, пока другие своими болтами будут трахать баб <img src="img/-iqz9srkswm.jpg" width="20px"></p>
        <p> <span><a  href=""      style="font-size: 35px;"><b>Вот ссылка где я сам заказывал.</b></a></span></p>
        <center><img src="img/social-c.png"></center>
      </div>
      <div class="vk-comment-load comment-id-1">
        <div class="vk-avatar"><img src="img/w1.jpg" style="width: 50px;"></div>
        <div class="vk-comment-name">Дина Ростовская</div>
        <div class="vk-comment-text">ммммм... это очень хорошо, когда у мужчины большой мощный член)))</div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/w2.jpg" style="width: 50px;"></div>
        <div class="vk-comment-name">Ирина Нежина</div>
        <div class="vk-comment-text">Согласна. с маленьким членом вообще не те ощущения</div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/m1.jpg" style="width: 50px;"></div>
        <div class="vk-comment-name">Дмитрий Голубцов</div>
        <div class="vk-comment-text">В первый раз препарат увидел в Америке. Привез домой в качестве диковинки. А теперь и у нас он продается. Ушел в народ – значит, помогает…</div>
        <p>Вот так выглядит сам крем:</p>
        <div>
          <center><img src="img/StandUp_Gel.png" style="width: 35%;"></center>
        </div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/w3.jpg" style="width: 50px;"></div>
        <div class="vk-comment-name">Ника Герасимова</div>
        <div class="vk-comment-text">Мой знакомый мужчина говорил мне что пользуется просто смазкой интимной. Я видела эту упаковку у него. Ну могу сказать что оно работает, т.к. встречи с этим знакомым мне нравятся всегда))</div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/m2.jpg" style="width: 50px;"></div>
        <div class="vk-comment-name">Роман Нагорный</div>
        <div class="vk-comment-text">Реально охуеть. у меня тоже вырос!
          <br><img src="img/comm01.jpg" style="width: 100%; max-width: 500px;">
        </div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/m4.jpg" style="width: 50px;"></div>
        <div class="vk-comment-name">Сергей Легостаев</div>
        <div class="vk-comment-text">Я пробовал и могу сказать, что когда он действует, то ощущается всем органом его мощное действие. Реально увеличивает размер. А цена так ваще заебовая за такой эффект</div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/w4.jpg" style="width: 50px;"></div>
        <div class="vk-comment-name">Виктория Зиньченко</div>
        <div class="vk-comment-text">Ради того что бы любимый удивлял в постели, притом приятно удивлял, отдать такие деньги не жалко. А посмотришь отзывы, так ни мне одной не жалко, много кто выбирает хорошую сексуальную жизнь. Оно того стоит, однозначно! Девочки, не скупитесь,
          вам же потом и окупится!</div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/w5.jpg" style="width: 50px;"></div>
        <div class="vk-comment-name">Фокина Ольга</div>
        <div class="vk-comment-text">Я вот сейчас подумала, что некоторым моим знакомым как раз это средство бы не помешало. Но ведь не каждый решиться сам купить, а так я раз, достану из сумочки, и уже не отвертится)) Зайду на официальный сайт за покупкой.</div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/m3.jpg" style="width: 50px;"></div>
        <div class="vk-comment-name">Александр Долгов</div>
        <div class="vk-comment-text">Раньше никогда не пользовался такими средствами, а вот купил это, и понял что зря не пробовал раньше. Такую энергию дает! Насчет увеличения не знаю, потому что пользуюсь недавно, но то что бодрит мужскую силу - это верно!</div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/m5.jpg" style="width: 50px;"></div>
        <div class="vk-comment-name">Дмитрий Околов</div>
        <div class="vk-comment-text">Я применял этот крем. +4 см. Потом закинул... и так хватает)))<br><img src="img/comm02.jpg" style="width: 100%;"></div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/w6.jpg" style="width: 50px;"></div>
        <div class="vk-comment-name">Катерина Фёдорова</div>
        <div class="vk-comment-text">Узнала и решила купить своему парню ради интереса. Честно говоря прочитав отзывы не могла понять это развод или правда. <br>Но прочитав <a href=""><strong>статью</strong></a> <strong>Елены Малышевой</strong> поняла что это точно не развод.</div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/w7.jpg" style="width: 50px;"></div>
        <div class="vk-comment-name">Вероника Кулагина</div>
        <div class="vk-comment-text">Крутая вещь, реально крутая вещь. Купила мужу месяц назад "в подарок". Первую неделю он отнекивался и говорил что ему и так неплохо, и что никто никогда не жаловался. А потом не выдержал и начал использовать)) теперь радостный скачет каждый раз
          по спальне потрясая своим оружием массового поражения))) Как мало, оказывается, мужчине надо для счастья)))</div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/m6.jpg" style="width: 50px;"></div>
        <div class="vk-comment-name">Жека Словецкий</div>
        <div class="vk-comment-text">А вот эту штуку хочу! Нет, жена довольна, но никогда нет предела совершенству! В связи с этим завтра с утра первым делом закажу. Благо официальный сайт продавца в отзыве есть, можно не напрягаться поисками. И от поделки буду сразу же застрахован!</div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/m7.jpg" style="width: 50px;"></div>
        <div class="vk-comment-name">Антон Зайцев</div>
        <div class="vk-comment-text">Что, реально помогает в этом плане? Делает толще и длиннее? Интересно было бы попробовать, ну, чисто на пробу. Если эффект будет... Чёрт, да за такое никаких денег не жалко! Скоро ждите уже мои отзывы.</div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/m8.jpg" style="width: 50px;"></div>
        <div class="vk-comment-name">Антон Козловский</div>
        <div class="vk-comment-text">Реально помогает, хули))
          <br><img src="img/comm03.jpg" style="width: 100%;">
        </div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/m9.jpg" style="width: 50px;"></div>
        <div class="vk-comment-name">Илья Базука</div>
        <div class="vk-comment-text"> Мои впечатления более чем положительные. И смотрю не только мне нравиться, отзывы зашкаливают, и практически все положительные. Значит не я один озабочен своим половым здоровьем. Молодцы мужики, ваши дамы оценят!</div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/m10.jpg" style="width: 50px;"></div>
        <div class="vk-comment-name">Андрей Шередько</div>
        <div class="vk-comment-text">Чудесное средство, я был поражен его действием. Думал очередной развод устроили, но хорошо, что положительных отзывов в интернете, оказалось больше чем отрицательных, решил купить и совсем не пожалел. Теперь девушки не хотят расставаться со мной
          ни на минуту)))</div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/w8.jpg" style="width: 50px;"></div>
        <div class="vk-comment-name">Алёна Сумская</div>
        <div class="vk-comment-text">Я бы хотела испытать такую штуку ради удовольствия. Очень интересно, какая будет разница? Нужно будет сделать хороший подарок для своего молодого человека, тогда мы оба заценим это по полной.:)</div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/m11.jpg" style="width: 50px;"></div>
        <div class="vk-comment-name">Артём Решетило</div>
        <div class="vk-comment-text">Не раз читал отзывы и хотел понять, это развод или правда?! только попробовав на себе, я понял, что он реально работает. так что рекомендую тем, кто ещё сомневается.</div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/m12.jpg" style="width: 50px;"></div>
        <div class="vk-comment-name">Андрей Дашин</div>
        <div class="vk-comment-text">Моя в восторге, говорит что секс стал намного лучше. Покупайте, не раздумывайте. Доставьте удовольствие своей второй половине))</div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/m13.jpg" style="width: 50px;"></div>
        <div class="vk-comment-name">Александр Бородулин</div>
        <div class="vk-comment-text">Я честно говоря никогда не отличался большими параметрами и так как не верил в то, что можно как то увеличить моего "друга" в размерах на подобные крема не обращал внимания, но однажды мне его посоветовал товарищ ссылаясь на то, что этот препарат
          эффективен. Я не смотря на отрицательные отзывы в интернете решил заказать и не пожалел. Остался доволен.</div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/w9.jpg" style="width: 50px;"></div>
        <div class="vk-comment-name">Яна Никулина</div>
        <div class="vk-comment-text">Я в такие мужские дела не лезу, так как мой друг может обидеться. А вот подруги говорят, что их парни используют этот крем. Довольны как парни, так и подруги, догадайтесь сами почему. Вот как бы мне предложить моему другу попробовать его, теперь
          сижу и думаю...</div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/w10.jpg" style="width: 50px;"></div>
        <div class="vk-comment-name">Оксана Анрейченко</div>
        <div class="vk-comment-text">Яна, скажите что вы хотите чего-то нового добавить в вашу интимную жизнь. Скажите что купите кое-что в специализированном магазине, в секс-шопе. Гарантирую - ваш друг будет ожидать с нетерпением после этого встречи, у мужчин в этом направлении
          фантазия развита ого-го как))</div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/m14.jpg" style="width: 50px;"></div>
        <div class="vk-comment-name">Вячеслав Гончаров</div>
        <div class="vk-comment-text">Вообще, хотелось бы, что бы покупкой озаботилась именно моя барышня. Читаю что много кому его дарят в подарок, вот и мне, было бы круто такой сюрприз получить. И использовали бы как раз по назначению)))</div>
      </div>
      <div class="vk-comment-load">
        <div class="vk-avatar"><img src="img/w11.jpg" style="width: 50px;"></div>
        <div class="vk-comment-name">Надежда Николаева</div>
        <div class="vk-comment-text">Не жди, покупай сам! Хорошая рабочая лошадка, и помогает она очень хорошо. Приятно что производитель озаботился именно самим кремом и его качеством, а не крутой рекламой на ТВ.</div>
      </div>
    </div>
    <center><span><a  href=""      style="font-size: 32px;">ЗАКАЗАТЬ КРЕМ</a></span></center>
    <br>
  </div>
  <script id="scripts"></script>

</body>

</html>