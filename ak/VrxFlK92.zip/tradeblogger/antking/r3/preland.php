<?php
$siteTokenDefault = 'antking/r3';
require('../../../lib/start.preland.php');