<?php require('preland.php'); ?>
<!DOCTYPE html>
<html>

<head style="height: 100%;">
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">



  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="shortcut icon" href="assets/favicon.png">
  <title>Мой муж увеличил член на 5,5 см. Я невероятно счастлива!</title>



  <style>
    .-left {
      float: left;
      margin: 0 15px 15px 0;
      width: 50%;
      background: rgba(114, 168, 211, 0.2);
    }

    .-div-img p {
      font-size: 13px;
      color: grey;
      margin: 0;
      text-align: center;
      font-weight: bold;
      padding-bottom: 5px;
    }

    .-div-img img {
      width: 100%;
    }

    .-right {
      float: right;
      margin: 0 0 15px 15px;
      ;
      width: 50%;
      background: rgba(114, 168, 211, 0.2);
    }

    .-center {
      text-align: center;
      width: 90%;
      margin: 0 auto;
      background: rgba(114, 168, 211, 0.2);
    }

    .-p-first {
      font-style: italic;
      color: grey;
    }

    @media screen and (max-width:480px) {

      .-left,
      .-right {
        float: none;
        width: 90%;
        margin: 0 auto;
      }
    }
  </style>

  <link media="all" href="assets/style.css" type="text/css" rel="stylesheet">
</head>

<body style="height:100%;">
  <header></header>




  <div class="container">

    <main>
      <h1>У мужа теперь член 20см (был 13,5). Я невероятно счастлива!</h1>
      <div class="-div-img -right"><img src="assets/img12.gif" alt=""></div>

      <p><i>Теперь мы с мужем не вылазим из постели. Послушайте мои советы, чтобы узнать, как увеличить член и сохранить
          отношения!</i></p>
      <p>Я очень люблю своего мужа, невероятно люблю! Он хорошо зарабатывает и вообще просто идеальный муж. Но меня не
        устраивал секс с ним. Его ковбой был всего 13 см, а заканчивал он уже через 15 минут. <img
          src="assets/smile30.jpg" style="width: 20px;">
        Я поначалу думала, что это нормально и смогу справиться с этим, что размер не важен...Но к сожалению, нет, это
        не так!</p>
      <p>Я никогда не была удовлетворена в сексуальном плане. А секс я очень люблю. Можете представить какой это ад <img
          src="assets/smile46.jpg" style="width: 20px;"> Конечно, <b>я делала вид, что испытываю оргазм.</b>
        Мой муж думал, что все нормально у нас в сексе.</p>
      <p> Из-за этого была постоянно злая и раздраженная.
        Понимаю, что это не его вина, но терпеть я это больше не могла. <b>Я даже думала об измене!</b><img
          src="assets/smile37.jpg" style="width: 20px;"></p>
      <p>Единственный выход, который я нашла - развод...</p>



      <p>Целый месяц я сидела с мыслями о разводе. Я была холодна с мужем, <b>сексом мы не занимались.</b> Он не понимал
        в чем дело.
        Я надеялась, что если буду так себя вести, то ему будет легче пережить расставание.</p>



      <p>Но наступил день, когда я ему собиралась все сказать. Я подошла к нему, чтобы сообщить о разводе, но не
        успела...</p>
      <p>И тут внезапно случилось <b>то, что я так ждала от него</b>!</p>
      <p>Он схватил меня и начал страстно целовать. Его руки скользили по моему телу, я просто не могла сопротивляться.
        Он никогда не был таким уверенным в себе.<img src="assets/smile47.jpg" style="width: 20px;">
      </p>
      <p>Я начала возбуждаться. С ним такой мокрой я никогда еще не была... Я вдруг почувствовала в нем сильного самца,
        которому я должна отдаться полностью.
        У меня никогда таких мыслей по отношению к мужу не возникало, если честно.</p>
      <div class="-div-img -right">
        <img src="assets/post1.jpg" alt=""><br>
        <p></p>
      </div>
      <p>Я опустила руку, чтобы потрогать его член и... ПРОСТО ОФИГЕЛА!
        Это был не обычный средненький пенис, а <b>ГРОМАДНЫЙ ЧЛЕН. ЧЛЕНИЩЕ!</b><img src="assets/smile14.jpg"
          style="width: 20px;">
        Я не понимала, как такое может быть. Мне даже стало немного страшно.
        Но мне уже было все равно. От этого мощного крепкого члена я просто потеряла голову.</p>
      <p>Я не удержалась, спустилась на колени и начала жадно обсасывать этот каменный член.
        Никогда еще мне так не хотелось полностью вылизать член и полностью запихнуть его в глотку.
        Я хотела, чтоб этот член залил меня спермой. Я сосала минут 20, но <b>он и не думал кончать</b>.<img
          src="assets/smile21.jpg" style="width: 20px;"></p>
      <p>Муж поставил меня в позу и вошел в меня. У меня аж дыхание остановилось.
        Мне было сначала больно, но в то же время дико круто от этого большого члена.
        Я чувствовала каждую жилку, каждый сосуд.<img src="assets/smile29.jpg" style="width: 20px;"></p>
      <p>Пока он меня имел, <b>я успела испытать 3 ОРГАЗМА.</b> И внимание! Я узнала что такое сквирт))) Думала что это
        все чушь и такого не бывает. Даже не знала что я на такое способна. Раньше с мужем не было ни одного, а сквирта
        и подавно!
        Когда он закончил, я сползла на колени, чтоб получить порцию спермы на лицо.
        Спермы было много, ОЧЕНЬ МНОГО! Я с благодарностью приняла эту теплую жидкость и
        с жадностью слизала остатки с его члена. Он все еще был крепким и сильно пульсировал после оргазма.
      </p>
      <p>Я чувствовала себя как в раю. Мои ноги дрожали, по телу все еще проходили не сильные судороги.
        Я лежала прямо на полу у ног мужа и не в силах была встать. Меня НИКОГДА ТАК НЕ ТРАХАЛИ!<img
          src="assets/smile6.jpg" style="width: 20px;"></p>

      <big><big>СЕКРЕТ МОЕГО МУЖА</big></big>
      <p></p>
      <p>Оказывается, он где-то узнал о специальном геле для увеличения члена. Сначала не поверил, думал, что это фигня
        какая-то и развод.</p>
      <div class="-div-img -left">
        <img src="assets/post3.jpg" alt=""><br>
        <p></p>
      </div>
      <p>Но потом он прочитал много отзывов и даже мнения врачей. Говорят, что если использовать НАСТОЯЩИЕ капсулы, то
        <b>результат будет 100%.</b><img src="assets/smile59.jpg" style="width: 20px;">
        Просто продают много поделок, поэтому некоторые говорят, что не помогает.</p>
      <p>Муж поискал и нашел <a href="#scroll-to-boxes" class="btn" ><b>официальный сайт</b> где продают этот
          самые волшебные капсулы.</a>
        Говорит, что не зря попробовал. Доволен теперь как слон.</p>
      <p>Особенно из-за того, что я теперь НИКОГДА не позволяю себе начинать пилить ему мозг. Говорит, что&nbsp;<b>я
          стала на удивление послушной и покладистой</b>.&nbsp;Ну еще бы. После такого секса даже мысли о том, чтобы
        ругаться или разводится, не возникает. Теперь стало все идеально!&nbsp;<img src="assets/smile1.jpg"
          style="width: 20px;"></p>
      <div class="-div-img -right">
        <img src="assets/21336505.gif" alt=""><br>
        <p></p>
      </div>
      <p>Теперь у нас бурная сексуальная жизнь. Я не думала раньше, что буду так <b> обожать секс.</b><img
          src="assets/smile2.jpg" style="width: 20px;">
        Каждый день с нетерпением жду своего мужа с работы. Особенно ему нравится, когда я подползаю к нему на коленях
        и начинаю ласкать его член. А мне и самой в удовольствие делать ему минет. <img src="assets/smile52.jpg"
          style="width: 20px;"></p>
      <p>Ради своего мужчины <b>я даже начала больше следить ухаживать за собой.</b> Я похудела, начала ходить в
        тренажерный зал.
        А все для того, чтобы быть для Него идеальной. Чтоб он никогда не переставал меня хотеть.<img
          src="assets/smile24.jpg" style="width: 20px;"></p>
      <p>Конечно, не все так сладко. Я узнала, что мой муж стал мне иногда изменять. <img src="assets/smile42.jpg"
          style="width: 20px;">
        Женщины стали сами к нему как-то тянутся. Видимо, чувствуют его сильную энергию.<img src="assets/smile10.jpg"
          style="width: 20px;"></p>
      <p> Мне конечно сначала было очень обидно. Но потом я поняла, что с кем бы он мне не изменял, главное что он
        остается со мной...
        <b>А такому Мужчине можно простить всё</b> лишь бы он был с тобой рядом.<img src="assets/smile18.jpg"
          style="width: 20px;">
        Делаю вид, что не знаю о его похождениях, ну и стараюсь не думать об этом.
      </p>
      <big><big>МОЙ ВАМ СОВЕТ</big></big>
      <p></p>
      <p>Как бы там ни было. Я ВСЕМ рекомендую попробовать &laquo;ANT KING&raquo;. Мужчины, радуйте своих
        женщин.
        Поверьте, они потом вам за это будут очень благодарны. Когда вы сможете давать своей любимой
        невероятный секс, вы ее потом не узнаете. </p>
      <p>Сексуально удовлетворенная женщина <b>сделает для тебя ВСЁ</b> что ты захочешь. И даже больше<img
          src="assets/smile9.jpg" style="width:20px;"></p>











      <div id="scroll-to-boxes">
        <center>
          <div id="boxesContainer">
            <h2>Откройте коробку и получите возможность заказать ANT KING за полцены или вовсе СО СКИДКОЙ</h2><br>
            <h3 style="color:red;">Осталось 47 упаковок со скидкой!</h3>
            <div class="instructions"> Откройте коробку!
              <table>
                <tbody>
                  <tr>
                    <td>
                      <span class="bounce">↓</span>
                    </td>
                    <td>

                    </td>
                    <td><span class="bounce">↓</span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div id="boxes" class="boxes boxesfirsttry">
              <div id="0">
                <img src="assets/box_c.png" class="try">
                <img src="assets/download.png" class="opentry">
                <span class="boxtext">ГЕЛЬ<br>за <?= $newPriceHtml ?> <?= $currencyDisplayHtml ?></span>
              </div>
              <div id="1">
                <img src="assets/box_c.png" class="try">
                <img src="assets/download.png" class="opentry">
                   <span class="boxtext">ГЕЛЬ<br>за <?= $newPriceHtml ?> <?= $currencyDisplayHtml ?></span>
              </div>
              <div id="2">
                <img src="assets/box_c.png" class="try">
                <img src="assets/download.png" class="opentry">
                   <span class="boxtext">ГЕЛЬ<br>за <?= $newPriceHtml ?> <?= $currencyDisplayHtml ?></span>
              </div>
              <div id="3">
                <img src="assets/box_c.png" class="try">
                <img src="assets/download.png" class="opentry">
                   <span class="boxtext">ГЕЛЬ<br>за <?= $newPriceHtml ?> <?= $currencyDisplayHtml ?></span>
              </div>
              <div id="4">
                <img src="assets/box_c.png" class="try">
                <img src="assets/download.png" class="opentry">
                   <span class="boxtext">ГЕЛЬ<br>за <?= $newPriceHtml ?> <?= $currencyDisplayHtml ?></span>
              </div>
              <div id="5">
                <img src="assets/box_c.png" class="try">
                <img src="assets/download.png" class="opentry">
                    <span class="boxtext">ГЕЛЬ<br>за <?= $newPriceHtml ?> <?= $currencyDisplayHtml ?></span>
              </div>
              <div id="6">
                <img src="assets/box_c.png" class="try">
                <img src="assets/download.png" class="opentry">
                    <span class="boxtext">ГЕЛЬ<br>за <?= $newPriceHtml ?> <?= $currencyDisplayHtml ?></span>
              </div>
              <div id="7">
                <img src="assets/box_c.png" class="try">
                <img src="assets/download.png" class="opentry">
                    <span class="boxtext">ГЕЛЬ<br>за <?= $newPriceHtml ?> <?= $currencyDisplayHtml ?></span>
              </div>
              <div id="8">
                <img src="assets/box_c.png" class="try">
                <img src="assets/download.png" class="opentry">
                    <span class="boxtext">ГЕЛЬ<br>за <?= $newPriceHtml ?> <?= $currencyDisplayHtml ?></span>
              </div>
            </div>


            <div id="shadow"></div>

            <div class="sweet-overlay" style="opacity: 1.03; display: none;" tabindex="-1"></div>
            <div class="sweet-alert animated bounceIn" id="modal02">
              <div class="sa-icon sa-success" id="success02">
                <span class="sa-line sa-tip" id="successtip02"></span> <span class="sa-line sa-long"
                  id="successlong02"></span>
                <div class="sa-placeholder"></div>
                <div class="sa-fix"></div>
              </div>
              <p id="cnt">
                У вас осталась 1 попытка! <br> Попробуйте ещё раз!</p>
              <div class="sa-button-container">
                <div class="sa-confirm-button-container">
                  <span id="update"
                    style="display: inline-block; box-shadow: rgba(140, 212, 245, 0.8) 0px 0px 2px, rgba(0, 0, 0, 0.0470588) 0px 0px 0px 1px inset; background-color: #FFA400;     padding: 15px 20px;
    border-radius: 5px;
    margin: 20px auto;">
                    OK
                  </span>
                  <div class="la-ball-fall"></div>
                </div>
              </div>
            </div>


          </div>

          <div name="order0" id="order0"></div>
          <span name="order0" id="order0"> </span>
          <span class="toform" id="toform"></span>
          <!---BOXES--->

          <div class="order_block">
            <center><img src="assets/product.png" style="max-height: 300px"></center>
            <br>
            <div class="price-block" style="text-align:center;">

             

            </div><br><br>

            <center>
              <h3 style="padding-top: 15px; text-align: center; margin: -50px 0; font-size: 17px;">
                Все что Вам нужно - забрать &laquo;ANT KING&raquo; СО СКИДКОЙ. <br>Поторопитесь!
                У вас
                осталось времени:
              </h3>
            </center>

            <div style="margin-top:65px;">

              <div class="clock">03:49</div>
              <script>
                var interval = setInterval(function () {
                  var timer = $('.clock').html();
                  timer = timer.split(':');
                  var minutes = parseInt(timer[0], 10);
                  var seconds = parseInt(timer[1], 10);
                  seconds -= 1;
                  if (minutes < 0) return clearInterval(interval);
                  if (minutes < 10 && minutes.length != 2) minutes = '0' + minutes;
                  if (seconds < 0 && minutes != 0) {
                    minutes -= 1;
                    seconds = 59;
                  } else if (seconds < 10 && length.seconds != 2) seconds = '0' + seconds;
                  $('.clock').html(minutes + ':' + seconds);
                  if (minutes == 0 && seconds == 0)
                    clearInterval(interval);
                }, 1000);
              </script>




              <div id="countdown"></div>
              <br>
              <center>
                <div class="delivery"><b style="font-size: 130%">Доставка Новой Почтой</b></div>
              </center>


                  <center><button type="submit" class="strong-brown lnk ifr_button button7" style=" border: 0; margin-top: 15px;cursor:pointer; ">Получить ANT KING СО СКИДКОЙ</button></center>




            </div>

          </div>
          <div class="spin-result-wrapper">
            <div class="pop-up-window">
              <div class="close-popup"></div>
              <span class="pop-up-heading">Поздравляем!</span>
              <p class="pop-up-text">Вы можете забрать<br>&laquo;ANT KING&raquo;
              <div class="price-block" style="text-align:center;">

               
                <span class="new-price">СО СКИДКОЙ</span>
              </div>
              </p>
              <a class="pop-up-button lnk" href="#scroll-to-boxes">Ok</a>
            </div>
          </div>
        </center>
      </div>

      <script src="assets/jquery.min.js"></script>
      <script src="assets/inputmask.js"></script>
      <script>
        $(document).ready(function () {
          $("a[href^='#']").click(function () {
            var _href = $(this).attr("href");
            $("html, body").animate({
              scrollTop: $(_href).offset().top + "px"
            });
            return false;
          });

          $('.boxes > div').click(function () {
            if ($(this).parent().hasClass('boxesfirsttry')) {
              $('.boxes').removeClass('boxesfirsttry');
              $(this).addClass('openbox');
              $(this).find('.try').hide();
              $(this).find('.opentry').show();
              setTimeout(function () {
                $('.sweet-overlay').show();
                $('.sweet-alert').show();
              }, 500);
            } else if ($(this).parent().hasClass('boxeslasttry')) {
              if (!$(this).hasClass('openbox')) {
                $(this).find('.try').hide();
                $(this).find('.opentry').show();
                $(this).find('.boxtext').css('display', 'block');
                setTimeout(function () {
                  if ($(".new-comebacker-overlay").is(":visible")) $(".new-comebacker-overlay").hide();
                  $(".new-comebacker-overlay .boxes-is-open").show();
                  $(".new-comebacker-overlay .boxes-not-open").hide();
                  $('.spin-result-wrapper').show();
                  setTimeout(function () {
                    $('#boxesContainer').slideUp(250);
                    setTimeout(function () {
                      $('.order_block').slideDown(250);
                    }, 500)
                  }, 500)
                }, 500);
              }
            }

          });

          $('#update').click(function () {
            $('.sweet-overlay').hide();
            $('.sweet-alert').hide();
            $('.boxes').addClass('boxeslasttry');
          });

          $('.pop-up-button, .close-popup').click(function () {
            $('.spin-result-wrapper').hide();
            $('#countdown, #countdown-modal').timeTo(180);
          })
        });

      </script>
      <link media="all" href="assets/box.css" type="text/css" rel="stylesheet">















      <br><br>
      <center>
        <div class="addthis_inline_share_toolbox_68af" data-url="default.htm" data-title="Идеальный секс глазами мужчин и женщин"
          data-description="Представители прекрасного и сильного полов поделились своими представлениями о сексе. Оказалось, что мнения во многом разделились"
          style="clear: both;">
          <div id="atstbx" class="at-share-tbx-element addthis-smartlayers addthis-animated at4-show"
            aria-labelledby="at-a21260e0-9403-48f8-bb97-024b8910bcb5" role="region"><span
              id="at-a21260e0-9403-48f8-bb97-024b8910bcb5" class="at4-visually-hidden">AddThis Sharing Buttons</span>
            <div class="at-share-btn-elements"><a role="button" tabindex="1"
                class="at-icon-wrapper at-share-btn at-svc-facebook"
                style="background-color: rgb(59, 89, 152); border-radius: 0px;" ><span
                  class="at4-visually-hidden">Share to Facebook</span><span class="at-icon-wrapper"
                  style="line-height: 32px; height: 32px; width: 32px;"><svg xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 32 32" version="1.1" role="img"
                    aria-labelledby="at-svg-facebook-1" style="fill: rgb(255, 255, 255); width: 32px; height: 32px;"
                    class="at-icon at-icon-facebook">
                    <title id="at-svg-facebook-1">Facebook</title>
                    <g>
                      <path
                        d="M22 5.16c-.406-.054-1.806-.16-3.43-.16-3.4 0-5.733 1.825-5.733 5.17v2.882H9v3.913h3.837V27h4.604V16.965h3.823l.587-3.913h-4.41v-2.5c0-1.123.347-1.903 2.198-1.903H22V5.16z"
                        fill-rule="evenodd"></path>
                    </g>
                  </svg></span><span class="at-label"
                  style="font-size: 11.4px; line-height: 32px; height: 32px; color: rgb(255, 255, 255);">Facebook</span></a><a
                role="button" tabindex="1" class="at-icon-wrapper at-share-btn at-svc-telegram"
                style="background-color: rgb(0, 136, 204); border-radius: 0px;" ><span
                  class="at4-visually-hidden">Share to Telegram</span><span class="at-icon-wrapper"
                  style="line-height: 32px; height: 32px; width: 32px;"><svg xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 32 32" version="1.1" role="img"
                    aria-labelledby="at-svg-telegram-2" style="fill: rgb(255, 255, 255); width: 32px; height: 32px;"
                    class="at-icon at-icon-telegram">
                    <title id="at-svg-telegram-2">Telegram</title>
                    <g>
                      <g fill-rule="evenodd"></g>
                      <path
                        d="M15.02 20.814l9.31-12.48L9.554 17.24l1.92 6.42c.225.63.114.88.767.88l.344-5.22 2.436 1.494z"
                        opacity=".6"></path>
                      <path d="M12.24 24.54c.504 0 .727-.234 1.008-.51l2.687-2.655-3.35-2.054-.344 5.22z" opacity=".3">
                      </path>
                      <path
                        d="M12.583 19.322l8.12 6.095c.926.52 1.595.25 1.826-.874l3.304-15.825c.338-1.378-.517-2.003-1.403-1.594L5.024 14.727c-1.325.54-1.317 1.29-.24 1.625l4.98 1.58 11.53-7.39c.543-.336 1.043-.156.633.214">
                      </path>
                    </g>
                  </svg></span><span class="at-label"
                  style="font-size: 11.4px; line-height: 32px; height: 32px; color: rgb(255, 255, 255);">Telegram</span></a><a
                role="button" tabindex="1" class="at-icon-wrapper at-share-btn at-svc-vk"
                style="background-color: rgb(99, 131, 168); border-radius: 0px;" ><span
                  class="at4-visually-hidden">Share to Vkontakte</span><span class="at-icon-wrapper"
                  style="line-height: 32px; height: 32px; width: 32px;"><svg xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 32 32" version="1.1" role="img"
                    aria-labelledby="at-svg-vk-3" style="fill: rgb(255, 255, 255); width: 32px; height: 32px;"
                    class="at-icon at-icon-vk">
                    <title id="at-svg-vk-3">Vkontakte</title>
                    <g>
                      <path
                        d="M26.712 10.96s-.167-.48-1.21-.348l-3.447.024a.785.785 0 0 0-.455.072s-.204.108-.3.37a22.1 22.1 0 0 1-1.28 2.695c-1.533 2.61-2.156 2.754-2.407 2.587-.587-.372-.43-1.51-.43-2.323 0-2.54.382-3.592-.756-3.868-.37-.084-.646-.144-1.616-.156-1.232-.012-2.274 0-2.86.287-.396.193-.695.624-.515.648.227.036.742.143 1.017.515 0 0 .3.49.347 1.568.13 2.982-.48 3.353-.48 3.353-.466.252-1.28-.167-2.478-2.634 0 0-.694-1.222-1.233-2.563-.097-.25-.288-.383-.288-.383s-.216-.168-.527-.216l-3.28.024c-.504 0-.683.228-.683.228s-.18.19-.012.587c2.562 6.022 5.483 9.04 5.483 9.04s2.67 2.79 5.7 2.597h1.376c.418-.035.634-.263.634-.263s.192-.214.18-.61c-.024-1.843.838-2.12.838-2.12.838-.262 1.915 1.785 3.065 2.575 0 0 .874.6 1.532.467l3.064-.048c1.617-.01.85-1.352.85-1.352-.06-.108-.442-.934-2.286-2.647-1.916-1.784-1.665-1.496.658-4.585 1.413-1.88 1.976-3.03 1.796-3.52z"
                        fill-rule="evenodd"></path>
                    </g>
                  </svg></span><span class="at-label"
                  style="font-size: 11.4px; line-height: 32px; height: 32px; color: rgb(255, 255, 255);">Vkontakte</span></a><a
                role="button" tabindex="1" class="at-icon-wrapper at-share-btn at-svc-google_plusone_share"
                style="background-color: rgb(220, 78, 65); border-radius: 0px;" ><span
                  class="at4-visually-hidden">Share to Google+</span><span class="at-icon-wrapper"
                  style="line-height: 32px; height: 32px; width: 32px;"><svg xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 32 32" version="1.1" role="img"
                    aria-labelledby="at-svg-google_plusone_share-4"
                    style="fill: rgb(255, 255, 255); width: 32px; height: 32px;"
                    class="at-icon at-icon-google_plusone_share">
                    <title id="at-svg-google_plusone_share-4">Google+</title>
                    <g>
                      <path
                        d="M12 15v2.4h3.97c-.16 1.03-1.2 3.02-3.97 3.02-2.39 0-4.34-1.98-4.34-4.42s1.95-4.42 4.34-4.42c1.36 0 2.27.58 2.79 1.08l1.9-1.83C15.47 9.69 13.89 9 12 9c-3.87 0-7 3.13-7 7s3.13 7 7 7c4.04 0 6.72-2.84 6.72-6.84 0-.46-.05-.81-.11-1.16H12zm15 0h-2v-2h-2v2h-2v2h2v2h2v-2h2v-2z"
                        fill-rule="evenodd"></path>
                    </g>
                  </svg></span><span class="at-label"
                  style="font-size: 11.4px; line-height: 32px; height: 32px; color: rgb(255, 255, 255);">Google+</span></a><a
                role="button" tabindex="1" class="at-icon-wrapper at-share-btn at-svc-twitter"
                style="background-color: rgb(29, 161, 242); border-radius: 0px;" ><span
                  class="at4-visually-hidden">Share to Twitter</span><span class="at-icon-wrapper"
                  style="line-height: 32px; height: 32px; width: 32px;"><svg xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 32 32" version="1.1" role="img"
                    aria-labelledby="at-svg-twitter-5" style="fill: rgb(255, 255, 255); width: 32px; height: 32px;"
                    class="at-icon at-icon-twitter">
                    <title id="at-svg-twitter-5">Twitter</title>
                    <g>
                      <path
                        d="M27.996 10.116c-.81.36-1.68.602-2.592.71a4.526 4.526 0 0 0 1.984-2.496 9.037 9.037 0 0 1-2.866 1.095 4.513 4.513 0 0 0-7.69 4.116 12.81 12.81 0 0 1-9.3-4.715 4.49 4.49 0 0 0-.612 2.27 4.51 4.51 0 0 0 2.008 3.755 4.495 4.495 0 0 1-2.044-.564v.057a4.515 4.515 0 0 0 3.62 4.425 4.52 4.52 0 0 1-2.04.077 4.517 4.517 0 0 0 4.217 3.134 9.055 9.055 0 0 1-5.604 1.93A9.18 9.18 0 0 1 6 23.85a12.773 12.773 0 0 0 6.918 2.027c8.3 0 12.84-6.876 12.84-12.84 0-.195-.005-.39-.014-.583a9.172 9.172 0 0 0 2.252-2.336"
                        fill-rule="evenodd"></path>
                    </g>
                  </svg></span><span class="at-label"
                  style="font-size: 11.4px; line-height: 32px; height: 32px; color: rgb(255, 255, 255);">Twitter</span></a><a
                role="button" tabindex="1" class="at-icon-wrapper at-share-btn at-svc-compact"
                style="background-color: rgb(255, 101, 80); border-radius: 0px;" ><span
                  class="at4-visually-hidden">Share to More</span><span class="at-icon-wrapper"
                  style="line-height: 32px; height: 32px; width: 32px;"><svg xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 32 32" version="1.1" role="img"
                    aria-labelledby="at-svg-addthis-6" style="fill: rgb(255, 255, 255); width: 32px; height: 32px;"
                    class="at-icon at-icon-addthis">
                    <title id="at-svg-addthis-6">Addthis</title>
                    <g>
                      <path d="M18 14V8h-4v6H8v4h6v6h4v-6h6v-4h-6z" fill-rule="evenodd"></path>
                    </g>
                  </svg></span><span class="at-label"
                  style="font-size: 11.4px; line-height: 32px; height: 32px; color: rgb(255, 255, 255);">More</span></a><span
                class="at_flat_counter" style="line-height: 32px; font-size:11.4px;">3634</span></div>
          </div>
        </div>
        <style>
          button.at4-closebutton {
            position: absolute;
            top: 0;
            right: 0;
            padding: 0;
            margin-right: 10px;
            cursor: pointer;
            background: transparent;
            border: 0;
            -webkit-appearance: none;
            font-size: 19px;
            line-height: 1;
            color: #000;
            text-shadow: 0 1px 0 #fff;
            opacity: .2
          }

          button.at4-closebutton:hover {
            color: #000;
            text-decoration: none;
            cursor: pointer;
            opacity: .5
          }

          div.at4-arrow {
            background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAAAoCAYAAABpYH0BAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAV1JREFUeNrsmesOgyAMhQfxwfrofTM3E10ME2i5Oeppwr9a5OMUCrh1XV+wcvNAAIAA+BiAzrmtUWln27dbjEcC3AdODfo0BdEPhmcO4nIDvDNELi2jggk4/k8dT7skfeKzWIEd4VUpMQKvNB7X+OZSmAZkATWC1xvipbpnLmOosbJZC08CkAeA4E6qFUEMwLAGnlSBPCE8lW8CYnZTcimH2HoT7kSFOx5HBmCnDhTIu1p5s98G+QZrxGPhZVMY1vgyAQaAAAiAAAgDQACcBOD+BvJtBWfRy7NpJK5tBe4FNzXokywV734wPHMQlxvgnSGyNoUP/2ACjv/7iSeYKO3YWKzAjvCqlBiBVxqPa3ynexNJwOsN8TJbzL6JNIYYXWpMv4lIIAZgWANPqkCeEJ7KNwExu8lpLlSpAVQarO77TyKdBsyRPuwV0h0gmoGnTWFYzVkYBoAA+I/2FmAAt6+b5XM9mFkAAAAASUVORK5CYII=);
            background-repeat: no-repeat;
            width: 20px;
            height: 20px;
            margin: 0;
            padding: 0;
            overflow: hidden;
            text-indent: -9999em;
            text-align: left;
            cursor: pointer
          }

          #at4-recommendedpanel-outer-container .at4-arrow.at-right,
          div.at4-arrow.at-right {
            background-position: -20px 0
          }

          #at4-recommendedpanel-outer-container .at4-arrow.at-left,
          div.at4-arrow.at-left {
            background-position: 0 0
          }

          div.at4-arrow.at-down {
            background-position: -60px 0
          }

          div.at4-arrow.at-up {
            background-position: -40px 0
          }

          .ats-dark div.at4-arrow.at-right {
            background-position: -20px -20px
          }

          .ats-dark div.at4-arrow.at-left {
            background-position: 0 -20px
          }

          .ats-dark div.at4-arrow.at-down {
            background-position: -60px -20px
          }

          .ats-dark div.at4-arrow.at-up {
            background-position: -40px -20
          }

          .at4-opacity-hidden {
            opacity: 0 !important
          }

          .at4-opacity-visible {
            opacity: 1 !important
          }

          .at4-visually-hidden {
            position: absolute;
            clip: rect(1px, 1px, 1px, 1px);
            padding: 0;
            border: 0;
            overflow: hidden
          }

          .at4-hidden-off-screen,
          .at4-hidden-off-screen * {
            position: absolute !important;
            top: -9999px !important;
            left: -9999px !important
          }

          .at4-show {
            display: block !important;
            opacity: 1 !important
          }

          .at4-show-content {
            opacity: 1 !important;
            visibility: visible
          }

          .at4-hide {
            display: none !important;
            opacity: 0 !important
          }

          .at4-hide-content {
            opacity: 0 !important;
            visibility: hidden
          }

          .at4-visible {
            display: block !important;
            opacity: 0 !important
          }

          .at-wordpress-hide {
            display: none !important;
            opacity: 0 !important
          }

          .addthis-animated {
            -webkit-animation-fill-mode: both;
            animation-fill-mode: both;
            animation-timing-function: ease-out;
            -webkit-animation-duration: .3s;
            animation-duration: .3s
          }

          .at-share-tbx-element {
            position: relative;
            margin: 0;
            color: #fff;
            font-size: 0
          }

          .at-share-tbx-element,
          .at-share-tbx-element .at-share-btn {
            font-family: helvetica neue, helvetica, arial, sans-serif;
            padding: 0;
            line-height: 0
          }

          .at-share-tbx-element .at-share-btn {
            cursor: pointer;
            margin: 0 5px 5px 0;
            display: inline-block;
            overflow: hidden;
            border: 0;
            text-decoration: none;
            text-transform: none;
            background-color: transparent;
            color: inherit;
            transition: all .2s ease-in-out
          }

          .at-share-tbx-element .at-share-btn:focus,
          .at-share-tbx-element .at-share-btn:hover {
            -webkit-transform: translateY(-4px);
            transform: translateY(-4px);
            outline-offset: -1px;
            color: inherit
          }

          .at-share-tbx-element .at-share-btn::-moz-focus-inner {
            border: 0;
            padding: 0
          }

          .at-share-tbx-element .at-share-btn.at-share-btn.at-svc-compact:hover {
            -webkit-transform: none;
            transform: none
          }

          .at-share-tbx-element .at-icon-wrapper {
            vertical-align: middle
          }

          .at-share-tbx-element .at4-share-count,
          .at-share-tbx-element .at-label {
            margin: 0 7.5px 0 2.5px;
            text-decoration: none;
            vertical-align: middle;
            display: inline-block;
            background: none;
            height: 0;
            font-size: inherit;
            line-height: inherit;
            color: inherit
          }

          .at-share-tbx-element.at-mobile .at4-share-count,
          .at-share-tbx-element.at-mobile .at-label {
            display: none
          }

          .at-share-tbx-element .at_native_button {
            vertical-align: middle
          }

          .at-share-tbx-element .addthis_counter.addthis_bubble_style {
            margin: 0 2px;
            vertical-align: middle;
            display: inline-block
          }

          .at-share-tbx-element .fb_iframe_widget {
            display: block
          }

          .at-share-tbx-element.at-share-tbx-native .at300b {
            vertical-align: middle
          }

          .at-icon-wrapper {
            display: inline-block;
            overflow: hidden;
          }

          .at_flat_counter {
            cursor: pointer;
            font-family: helvetica, arial, sans-serif;
            font-weight: 700;
            text-transform: uppercase;
            display: inline-block;
            position: relative;
            vertical-align: top;
            height: auto;
            margin: 0 5px;
            padding: 0 6px;
            left: -1px;
            background: #ebebeb;
            color: #32363b;
            transition: all .2s ease;
          }

          .at_flat_counter:after {
            top: 30%;
            left: -4px;
            content: "";
            position: absolute;
            border-width: 5px 8px 5px 0;
            border-style: solid;
            border-color: transparent #ebebeb transparent transparent;
            display: block;
            width: 0;
            height: 0;
            -webkit-transform: translateY(360deg);
            transform: translateY(360deg);
          }
        </style>



      </center>



      <div class="comments-container">
        <h1><a data-button="" href="#scroll-to-boxes" class="btn" >КОММЕНТАРИИ</a></h1>
        <ul id="comments-list" class="comments-list">

          <li>
            <div class="comment-main-level">
            </div>
          </li>
          <li>
            <div class="comment-avatar"><img src="assets/m1.jpg" alt=""></div>
            <div class="comment-box">
              <div class="comment-head">
                <h6 class="comment-name by-author"><a data-button="" href="#scroll-to-boxes" class="btn"
                    >Дмитрий Голубцов</a></h6>
                <span>15 минут назад</span>
                <i class="fa fa-reply"></i>
                <i class="fa fa-heart"></i>
              </div>
              <div class="comment-content">
                В первый раз ANT KING увидел в Америке. Привез домой в качестве диковинки. А теперь и у нас он
                продается. Ушел в народ – значит, помогает…
              </div>
            </div>
          </li>
          <div class="comment-main-level">
            <li>
              <div class="comment-avatar"><img src="assets/m2.jpg" alt=""></div>
              <div class="comment-box">
                <div class="comment-head">
                  <h6 class="comment-name by-author"><a data-button="" href="#scroll-to-boxes" class="btn"
                      >Роман Нагорный</a></h6>
                  <span>29 минут назад</span>
                  <i class="fa fa-reply"></i>
                  <i class="fa fa-heart"></i>
                </div>
                <div class="comment-content">
                  Реально охуеть. у меня тоже вырос!
                  <p></p>
                  <center><img src="assets/photo-orig.jpg"></center>
                </div>
              </div>
            </li>
            <div class="comment-main-level">
              <li>
                <div class="comment-avatar"><img src="assets/w6.jpg" alt=""></div>
                <div class="comment-box">
                  <div class="comment-head">
                    <h6 class="comment-name by-author"><a data-button="" href="#scroll-to-boxes" class="btn"
                        >Катерина Фёдорова</a></h6>
                    <span>47 минут назад</span>
                    <i class="fa fa-reply"></i>
                    <i class="fa fa-heart"></i>
                  </div>
                  <div class="comment-content">
                    Узнала и решила купить своему парню ради интереса. Честно говоря прочитав отзывы не могла понять это
                    развод или правда. Но результат подтвердил, что помогает.
                  </div>
                </div>
              </li>
              <li>
                <div class="comment-main-level">
                </div>
              </li>
              <li>
                <div class="comment-avatar"><img src="assets/w2.jpg" alt=""></div>
                <div class="comment-box">
                  <div class="comment-head">
                    <h6 class="comment-name by-author"><a data-button="" href="#scroll-to-boxes" class="btn"
                        >Ирина Нежина</a></h6>
                    <span>час назад</span>
                    <i class="fa fa-reply"></i>
                    <i class="fa fa-heart"></i>
                  </div>
                  <div class="comment-content">
                    Согласна. с маленьким членом вообще не те ощущения
                  </div>
                </div>
              </li>
              <li>
                <div class="comment-main-level">
                  <div class="comment-avatar"><img src="assets/w1.jpg" alt=""></div>
                  <div class="comment-box">
                    <div class="comment-head">
                      <h6 class="comment-name"><a data-button="" href="#scroll-to-boxes" class="btn" >Дина
                          Ростовская</a></h6>
                      <span>час назад</span>
                      <i class="fa fa-reply"></i><i class="fa fa-heart"></i>
                    </div>
                    <div class="comment-content">
                      ммммм... это очень хорошо, когда у мужчины большой мощный член)))
                      <p></p>
                      <center><img src="assets/neerav.jpg"></center>
                    </div>
                  </div>
                </div>
              </li>
              <li>
                <div class="comment-main-level">
                </div>
              </li>
              <li>
                <div class="comment-avatar"><img src="assets/w3.jpg" alt=""></div>
                <div class="comment-box">
                  <div class="comment-head">
                    <h6 class="comment-name by-author"><a data-button="" href="#scroll-to-boxes" class="btn"
                        >Ника Герасимова</a></h6>
                    <span>час назад</span>
                    <i class="fa fa-reply"></i>
                    <i class="fa fa-heart"></i>
                  </div>
                  <div class="comment-content">
                    Мой знакомый мужчина говорил мне что пользуется просто смазкой интимной. Я видела эту упаковку у
                    него. Ну могу сказать что оно работает, т.к. встречи с этим знакомым мне нравятся всегда))
                  </div>
                </div>
              </li>
              <div class="comment-main-level">
                <li>
                  <div class="comment-avatar"><img src="assets/w5.jpg" alt=""></div>
                  <div class="comment-box">
                    <div class="comment-head">
                      <h6 class="comment-name by-author"><a data-button="" href="#scroll-to-boxes" class="btn"
                          >Фокина Ольга</a></h6>
                      <span>два часа назад</span>
                      <i class="fa fa-reply"></i>
                      <i class="fa fa-heart"></i>
                    </div>
                    <div class="comment-content">
                      Я вот сейчас подумала, что некоторым моим знакомым как раз это средство бы не помешало. Но ведь не
                      каждый решиться сам купить, а так я раз, достану из сумочки, и уже не отвертится)) Зайду на <a
                        href="#scroll-to-boxes" class="btn" >официальный сайт</a> за покупкой.
                    </div>
                  </div>
                </li>
                <div class="comment-main-level">
                  <li>
                    <div class="comment-avatar"><img src="assets/w7.jpg" alt=""></div>
                    <div class="comment-box">
                      <div class="comment-head">
                        <h6 class="comment-name by-author"><a data-button="" href="#scroll-to-boxes" class="btn"
                            >Вероника Кулагина</a></h6>
                        <span>два часа назад</span>
                        <i class="fa fa-reply"></i>
                        <i class="fa fa-heart"></i>
                      </div>
                      <div class="comment-content">
                        Крутая вещь, реально крутая вещь. Купила мужу месяц назад "в подарок". Первую неделю он
                        отнекивался и говорил что ему и так неплохо, и что никто никогда не жаловался. А потом не
                        выдержал и начал использовать)) теперь радостный скачет каждый раз по спальне потрясая своим
                        оружием массового поражения))) Как мало, оказывается, мужчине надо для счастья)))
                      </div>
                    </div>
                  </li>
                  <div class="comment-main-level">
                    <li>
                      <div class="comment-avatar"><img src="assets/m3.jpg" alt=""></div>
                      <div class="comment-box">
                        <div class="comment-head">
                          <h6 class="comment-name by-author"><a data-button="" href="#scroll-to-boxes" class="btn"
                              >Сергей Легостаев</a></h6>
                          <span>три часа назад</span>
                          <i class="fa fa-reply"></i>
                          <i class="fa fa-heart"></i>
                        </div>
                        <div class="comment-content">
                          Я пробовал и могу сказать, что когда он действует, то ощущается всем органом его мощное
                          действие. Реально увеличивает размер. А цена так ваще заебовая за такой эффект

                          <br>

                        </div>
                      </div>
                    </li>
                    <div class="comment-main-level">
                      <li>
                        <div class="comment-avatar"><img src="assets/m4.jpg" alt=""></div>
                        <div class="comment-box">
                          <div class="comment-head">
                            <h6 class="comment-name by-author"><a data-button="" href="#scroll-to-boxes" class="btn"
                                >Дмитрий Околов</a></h6>
                            <span>три часа назад</span>
                            <i class="fa fa-reply"></i>
                            <i class="fa fa-heart"></i>
                          </div>
                          <div class="comment-content">
                            Я применял этот ANT KING. +4 см. Потом закинул... и так хватает)))
                            <p></p>
                            <center><img src="assets/comm01.jpg"></center>
                          </div>
                        </div>
                      </li>
                      <div class="comment-main-level">
                        <li>
                          <div class="comment-avatar"><img src="assets/w4.jpg" alt=""></div>
                          <div class="comment-box">
                            <div class="comment-head">
                              <h6 class="comment-name by-author"><a data-button="" href="#scroll-to-boxes" class="btn"
                                  >Виктория Зиньченко</a></h6>
                              <span>три часа назад</span>
                              <i class="fa fa-reply"></i>
                              <i class="fa fa-heart"></i>
                            </div>
                            <div class="comment-content">
                              Ради того что бы любимый удивлял в постели, притом приятно удивлял, отдать такие деньги не
                              жалко. А посмотришь отзывы, так ни мне одной не жалко, много кто выбирает хорошую
                              сексуальную жизнь. Оно того стоит, однозначно! Девочки, не скупитесь, вам же потом и
                              окупится!
                            </div>
                          </div>
                        </li>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </ul>
        <!--<center><a class="blue-btn no-hover btn" data-button="" href="" >Перейти на сайт поставщика</a></center>-->
        <br><br><br><br><br><br>
      </div>
    </main>
  </div>



  <footer>

    <center><b>2021 ©</b></center>
  </footer>







  
  <style>
    .screenLock {
      min-height: 100%;
      height: 100%;
      position: fixed;
      z-index: 999999;
      top: 0;
      left: 0;
      width: 100%;
      background: rgba(0, 0, 0, 0.7)
    }

    .msg {
      position: absolute;
      width: 600px;
      height: 300px;
      background: #1D2534;
      top: 0;
      left: 50%;
      margin-left: -300px;
      display: none;
      border-style: solid;
      border-color: #fff;
      border-width: 2px;
      border-radius: 7px;
      padding: 7px
    }

    .msg-title {
      font-size: 30px;
      font-family: Arial;
      text-align: center;
      color: #b6b6b6;
      font-weight: 700;
      margin-bottom: 15px;
      margin-top: 10px;
      line-height: 40px
    }

    .submit-popup {
      margin-top: 0px;
      text-transform: uppercase;
      font-size: 22px;
      font-family: Verdana;
      font-weight: 700;
      color: #fff;
      display: inline-block;
      background: none;
      border-style: none;
      border-color: #fff;
      border-width: 1px;
      line-height: 40px
    }
  </style>
  <script type="text/javascript">
    Date.prototype.addDays = function (d) {
      this.setDate(this.getDate() + d);
      return this;
    };
    $('document').ready(function () {
      var monthsList = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];
      var commentDate = $('span.comment_date');
      var comments = commentDate.length;
      var dates = [];
      var d = new Date();
      for (var i = comments - 1; i >= 0; i--) {
        var delta = Math.round(Math.random() * 2);
        var d = new Date(d.addDays(-delta));
        dates[i] = d.getDate() + ' ' + monthsList[d.getMonth()] + ' ' + d.getFullYear();
      }
      commentDate.each(function (i, el) {
        $(this).text(dates[i]);
      });
    });
  </script>
  
  <script src="js/comeback.js"></script>
  <script src="js/backbutton.js"></script>

</body>

</html>